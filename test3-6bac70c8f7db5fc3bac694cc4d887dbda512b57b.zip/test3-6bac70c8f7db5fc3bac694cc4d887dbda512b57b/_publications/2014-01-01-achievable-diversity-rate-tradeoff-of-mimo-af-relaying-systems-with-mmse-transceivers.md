---
title: "Achievable Diversity-Rate Tradeoff of MIMO AF Relaying Systems with MMSE Transceivers"
collection: publications
category: conferences
permalink: /publication/2014-01-01-achievable-diversity-rate-tradeoff-of-mimo-af-relaying-systems-with-mmse-transceivers
date: 2014-01-01
venue: 'ISIT 2014.'
paperurl: ''
citation: 'Changick Song and Cong Ling "<a href=''>Achievable Diversity-Rate Tradeoff of MIMO AF Relaying Systems with MMSE Transceivers</a>", ISIT 2014.'
---
