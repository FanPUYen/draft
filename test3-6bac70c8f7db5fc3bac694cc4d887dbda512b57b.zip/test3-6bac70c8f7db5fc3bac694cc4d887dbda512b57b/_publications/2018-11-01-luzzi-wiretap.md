---
title: "Almost universal codes for MIMO wiretap channels"
collection: publications
category: manuscripts
permalink: /publication/2018-11-01-luzzi-wiretap
date: 2018-11-01
venue: 'IEEE Trans. Inform. Theory'
paperurl: 'https://arxiv.org/abs/1611.01428'
citation: 'Laura Luzzi, Roope Vehkalahti, Cong Ling. "<a href="https://arxiv.org/abs/1611.01428">Almost universal codes for MIMO wiretap channels</a>", <i>IEEE Trans. Inform. Theory</i>, vol. 64, pp. 7218-7241, Nov. 2018.'
---
