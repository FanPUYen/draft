---
title: "On Decision-Feedback Detection of Nondiagonal Differential Space-Time Modulation in Temporally Correlated Fading Channels"
collection: publications
category: conferences
permalink: /publication/2003-01-01-on-decision-feedback-detection-of-nondiagonal-differential-space-time-modulation-in-temporally-correlated-fading-channels
date: 2003-01-01
venue: 'in Proc. ICC’03'
paperurl: ''
citation: 'Cong Ling, K. H. Li and A. C. Kot "<a href=''>On Decision-Feedback Detection of Nondiagonal Differential Space-Time Modulation in Temporally Correlated Fading Channels</a>", in Proc. ICC’03, Anchorage, AL, May 2003, pp. 2648–2652.'
---
