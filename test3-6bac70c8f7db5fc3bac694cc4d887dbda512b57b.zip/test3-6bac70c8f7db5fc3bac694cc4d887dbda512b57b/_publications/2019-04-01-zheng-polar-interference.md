---
title: "Polar Coding Strategies for the Interference Channel with Partial-Joint Decoding"
collection: publications
category: manuscripts
permalink: /publication/2019-04-01-zheng-polar-interference
date: 2019-04-01
venue: 'IEEE Trans. Inform. Theory'
paperurl: 'https://arxiv.org/abs/1608.08742'
citation: 'Mengfan Zheng, Cong Ling, Wen Chen, Meixia Tao. "<a href="https://arxiv.org/abs/1608.08742">Polar Coding Strategies for the Interference Channel with Partial-Joint Decoding</a>", <i>IEEE Trans. Inform. Theory</i>, vol. 65, pp. 1973-1993, Apr. 2019.'
---
