---
title: "Atomic Norm Denoising-based Channel Estimation for Massive Multiuser MIMO Systems"
collection: publications
category: conferences
permalink: /publication/2015-01-01-atomic-norm-denoising-based-channel-estimation-for-massive-multiuser-mimo-systems
date: 2015-01-01
venue: 'ICC 2015.'
paperurl: ''
citation: 'Peng Zhang, Lu Gan, Sumei Sun, and Cong Ling "<a href=''>Atomic Norm Denoising-based Channel Estimation for Massive Multiuser MIMO Systems</a>", ICC 2015.'
---
