---
title: "Feasibility condition for interference alignment with diversity"
collection: publications
category: manuscripts
permalink: /publication/2011-01-01-feasibility-condition-for-interference-alignment-with-diversity
date: 2011-01-01
venue: 'IEEE Trans. Inform. Theory'
paperurl: ''
citation: 'Haishi Ning, Cong Ling, and Kin. K. Leung "<a href=''>Feasibility condition for interference alignment with diversity</a>", IEEE Trans. Inform. Theory, vol. 57, pp. 2902-2912, May 2011.'
---
