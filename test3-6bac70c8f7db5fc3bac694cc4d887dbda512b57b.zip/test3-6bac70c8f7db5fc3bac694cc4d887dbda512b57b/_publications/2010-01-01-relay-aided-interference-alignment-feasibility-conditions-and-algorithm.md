---
title: "Relay-aided interference alignment: Feasibility conditions and algorithm"
collection: publications
category: conferences
permalink: /publication/2010-01-01-relay-aided-interference-alignment-feasibility-conditions-and-algorithm
date: 2010-01-01
venue: 'IEEE Int. Symp. Inform. Theory’10'
paperurl: ''
citation: 'Hashi Ning, Cong Ling, and Kin K. Leung "<a href=''>Relay-aided interference alignment: Feasibility conditions and algorithm</a>", IEEE Int. Symp. Inform. Theory’10, Austin, US, June 2010.'
---
