---
title: "Family size of orthogonal Oppermann sequences"
collection: publications
category: manuscripts
permalink: /publication/2001-01-01-family-size-of-orthogonal-oppermann-sequences
date: 2001-01-01
venue: 'Electron. Lett.'
paperurl: ''
citation: 'Guozhen Zang and Cong Ling "<a href=''>Family size of orthogonal Oppermann sequences</a>", Electron. Lett., vol. 37, pp. 631-632, May 2001.'
---
