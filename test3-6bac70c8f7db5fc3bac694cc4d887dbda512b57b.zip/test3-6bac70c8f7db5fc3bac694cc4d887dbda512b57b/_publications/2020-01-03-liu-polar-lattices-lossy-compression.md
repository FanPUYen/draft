---
title: "Polar Lattices for Lossy Compression"
collection: publications
category: manuscripts
permalink: /publication/2020-01-03-liu-polar-lattices-lossy-compression
date: 2020-01-03
venue: 'IEEE Trans. Inform. Theory'
paperurl: ''
citation: 'Ling Liu, Jinwen Shi, Cong Ling. "Polar Lattices for Lossy Compression", <i>IEEE Trans. Inform. Theory</i>, to appear.'
---
