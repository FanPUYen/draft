---
title: "Despreading chip waveform design for coherent delay-locked tracking in DS/SS systems"
collection: publications
category: conferences
permalink: /publication/2002-01-01-despreading-chip-waveform-design-for-coherent-delay-locked-tracking-in-ds-ss-systems
date: 2002-01-01
venue: 'in Proc. ICC’2002'
paperurl: ''
citation: 'Xiaofu Wu, Cong Ling and Haige Xiang "<a href=''>Despreading chip waveform design for coherent delay-locked tracking in DS/SS systems</a>", in Proc. ICC’2002, New York.'
---
