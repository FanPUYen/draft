---
title: "Polar Coding for the Cognitive Interference Channel with Confidential Messages"
collection: publications
category: manuscripts
permalink: /publication/2018-01-15-zheng-polar-cognitive
date: 2018-01-15
venue: 'IEEE J. Sel. Areas Commun.'
paperurl: 'https://arxiv.org/abs/1710.10202'
citation: 'Mengfan Zheng, Wen Chen, Cong Ling. "<a href="https://arxiv.org/abs/1710.10202">Polar Coding for the Cognitive Interference Channel with Confidential Messages</a>", <i>IEEE J. Sel. Areas Commun.</i>, 2018.'
---
