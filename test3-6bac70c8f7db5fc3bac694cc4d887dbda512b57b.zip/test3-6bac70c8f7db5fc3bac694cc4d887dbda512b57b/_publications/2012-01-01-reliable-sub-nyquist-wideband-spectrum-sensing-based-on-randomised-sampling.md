---
title: "Reliable sub-Nyquist wideband spectrum sensing based on randomised sampling"
collection: publications
category: conferences
permalink: /publication/2012-01-01-reliable-sub-nyquist-wideband-spectrum-sensing-based-on-randomised-sampling
date: 2012-01-01
venue: '1st International Workshop on Compressed Sensing applied to Radar'
paperurl: ''
citation: 'B. Ahmad, W. Dai, and C. Ling "<a href=''>Reliable sub-Nyquist wideband spectrum sensing based on randomised sampling</a>", 1st International Workshop on Compressed Sensing applied to Radar, 2012, Bonn, Germany.'
---
