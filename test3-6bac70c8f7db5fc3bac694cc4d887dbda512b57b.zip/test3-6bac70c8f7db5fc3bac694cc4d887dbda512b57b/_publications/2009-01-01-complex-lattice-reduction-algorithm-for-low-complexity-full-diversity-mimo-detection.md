---
title: "Complex lattice reduction algorithm for low-complexity full-diversity MIMO detection"
collection: publications
category: manuscripts
permalink: /publication/2009-01-01-complex-lattice-reduction-algorithm-for-low-complexity-full-diversity-mimo-detection
date: 2009-01-01
venue: 'IEEE Trans. Signal Processing'
paperurl: ''
citation: 'Ying Hung Gan, Cong Ling, and Wai Ho Mow "<a href=''>Complex lattice reduction algorithm for low-complexity full-diversity MIMO detection</a>", IEEE Trans. Signal Processing, vol. 57, pp. 2701-2710, July 2009. MATLAB code for CLLL.'
---
