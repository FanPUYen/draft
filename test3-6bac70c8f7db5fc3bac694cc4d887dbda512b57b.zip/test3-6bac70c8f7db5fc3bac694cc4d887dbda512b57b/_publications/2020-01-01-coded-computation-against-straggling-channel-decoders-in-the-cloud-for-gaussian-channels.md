---
title: "Coded Computation Against Straggling Channel Decoders in the Cloud for Gaussian Channels"
collection: publications
category: conferences
permalink: /publication/2020-01-01-coded-computation-against-straggling-channel-decoders-in-the-cloud-for-gaussian-channels
date: 2020-01-01
venue: 'ISIT 2020.'
paperurl: 'https://arxiv.org/abs/1805.11698'
citation: 'Jinwen Shi, Cong Ling, Osvaldo Simeone, Jörg Kliewer "<a href=''>Coded Computation Against Straggling Channel Decoders in the Cloud for Gaussian Channels</a>", ISIT 2020.'
---
