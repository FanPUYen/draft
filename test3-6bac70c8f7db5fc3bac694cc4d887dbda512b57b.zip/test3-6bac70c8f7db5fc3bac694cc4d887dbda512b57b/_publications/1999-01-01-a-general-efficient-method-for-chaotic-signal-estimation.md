---
title: "A general efficient method for chaotic signal estimation"
collection: publications
category: manuscripts
permalink: /publication/1999-01-01-a-general-efficient-method-for-chaotic-signal-estimation
date: 1999-01-01
venue: 'IEEE Trans. Signal Processing'
paperurl: ''
citation: 'Ling Cong, Wu Xiaofu and Sun Songgeng "<a href=''>A general efficient method for chaotic signal estimation</a>", IEEE Trans. Signal Processing, vol. 47, pp. 1424-1427, May 1999.'
---
