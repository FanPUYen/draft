---
title: "Superposition Lattice Coding for Gaussian Broadcast Channel with Confidential Message"
collection: publications
category: conferences
permalink: /publication/2014-01-01-superposition-lattice-coding-for-gaussian-broadcast-channel-with-confidential-message
date: 2014-01-01
venue: 'IEEE Inform. Theory Workshop 2014 (invited paper).'
paperurl: ''
citation: 'Li Chia Choo and Cong Ling "<a href=''>Superposition Lattice Coding for Gaussian Broadcast Channel with Confidential Message</a>", IEEE Inform. Theory Workshop 2014 (invited paper).'
---
