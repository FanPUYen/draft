---
title: "On the proximity factors of lattice reduction-aided decoding"
collection: publications
category: manuscripts
permalink: /publication/2011-01-01-on-the-proximity-factors-of-lattice-reduction-aided-decoding
date: 2011-01-01
venue: 'IEEE Trans. Signal Processing'
paperurl: 'http://arxiv.org/abs/1006.1666'
citation: 'Cong Ling "<a href=''>On the proximity factors of lattice reduction-aided decoding</a>", IEEE Trans. Signal Processing, vol. 59, pp. 2795-2808, June 2011.'
---
