---
title: "Secure Distributed Matrix Computation with Discrete Fourier Transform"
collection: publications
category: manuscripts
permalink: /publication/2020-01-02-mital-secure-distributed-matrix-computation
date: 2020-01-02
venue: 'submitted'
paperurl: ''
citation: 'N. Mital, C. Ling, D. Gunduz. "Secure Distributed Matrix Computation with Discrete Fourier Transform," submitted.'
---
