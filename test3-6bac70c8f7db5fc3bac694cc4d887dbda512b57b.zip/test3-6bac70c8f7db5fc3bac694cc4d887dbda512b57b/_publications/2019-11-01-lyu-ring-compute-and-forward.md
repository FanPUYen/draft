---
title: "Ring Compute-and-Forward over Block-Fading Channels"
collection: publications
category: manuscripts
permalink: /publication/2019-11-01-lyu-ring-compute-and-forward
date: 2019-11-01
venue: 'IEEE Trans. Inform. Theory'
paperurl: 'https://arxiv.org/abs/1805.02073'
citation: 'Shanxiang Lyu, Antonio Campello, Cong Ling. "<a href="https://arxiv.org/abs/1805.02073">Ring Compute-and-Forward over Block-Fading Channels</a>", <i>IEEE Trans. Inform. Theory</i>, vol. 65, pp. 6931-6949, Nov 2019.'
---
