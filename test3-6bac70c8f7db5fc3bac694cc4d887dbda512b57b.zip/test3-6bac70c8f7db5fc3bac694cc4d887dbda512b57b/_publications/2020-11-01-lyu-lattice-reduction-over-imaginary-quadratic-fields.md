---
title: "Lattice Reduction over Imaginary Quadratic Fields"
collection: publications
category: manuscripts
permalink: /publication/2020-11-01-lyu-lattice-reduction-over-imaginary-quadratic-fields
date: 2020-11-01
venue: 'IEEE Trans. Signal Processing'
paperurl: ''
citation: 'Shanxiang Lyu, Christian Porter, Cong Ling. "Lattice Reduction over Imaginary Quadratic Fields", <i>IEEE Trans. Signal Processing</i>, vol. 68, pp. 6380-6393, Nov. 2020.'
---
