---
title: "A back-iteration method for reconstructing chaotic sequences in finite-precision machines"
collection: publications
category: manuscripts
permalink: /publication/2008-01-01-a-back-iteration-method-for-reconstructing-chaotic-sequences-in-finite-precision-machines
date: 2008-01-01
venue: 'Circuits'
paperurl: ''
citation: 'Cong Ling and Xiaofu Wu "<a href=''>A back-iteration method for reconstructing chaotic sequences in finite-precision machines</a>", Circuits, Syst., Signal Processing, vol. 27, pp. 883 – 891, Oct. 2008.'
---
