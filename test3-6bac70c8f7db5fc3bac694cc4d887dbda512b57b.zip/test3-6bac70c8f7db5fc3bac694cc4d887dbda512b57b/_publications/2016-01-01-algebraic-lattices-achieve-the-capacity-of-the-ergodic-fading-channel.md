---
title: "Algebraic lattices achieve the capacity of the ergodic fading channel"
collection: publications
category: conferences
permalink: /publication/2016-01-01-algebraic-lattices-achieve-the-capacity-of-the-ergodic-fading-channel
date: 2016-01-01
venue: 'ITW 2016.'
paperurl: ''
citation: 'Antonio Campello, Cong Ling and Jean-Claude Belfiore "<a href=''>Algebraic lattices achieve the capacity of the ergodic fading channel</a>", ITW 2016.'
---
