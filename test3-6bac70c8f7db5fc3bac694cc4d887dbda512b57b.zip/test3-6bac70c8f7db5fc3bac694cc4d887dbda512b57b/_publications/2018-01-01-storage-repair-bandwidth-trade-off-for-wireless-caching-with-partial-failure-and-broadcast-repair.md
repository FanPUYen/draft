---
title: "Storage-Repair Bandwidth Trade-off for Wireless Caching with Partial Failure and Broadcast Repair"
collection: publications
category: conferences
permalink: /publication/2018-01-01-storage-repair-bandwidth-trade-off-for-wireless-caching-with-partial-failure-and-broadcast-repair
date: 2018-01-01
venue: 'ITW 2018.'
paperurl: 'https://arxiv.org/abs/1807.00220'
citation: 'Nitish Mital, Katina Kralevska, Deniz Gunduz, Cong Ling "<a href=''>Storage-Repair Bandwidth Trade-off for Wireless Caching with Partial Failure and Broadcast Repair</a>", ITW 2018.'
---
