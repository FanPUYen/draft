---
title: "Lattice Gaussian Sampling by Markov Chain Monte Carlo: Bounded Distance Decoding and Trapdoor Sampling"
collection: publications
category: manuscripts
permalink: /publication/2019-06-01-wang-lattice-gaussian-sampling
date: 2019-06-01
venue: 'IEEE Trans. Inform. Theory'
paperurl: 'https://arxiv.org/abs/1704.02673'
citation: 'Zheng Wang and Cong Ling. "<a href="https://arxiv.org/abs/1704.02673">Lattice Gaussian Sampling by Markov Chain Monte Carlo: Bounded Distance Decoding and Trapdoor Sampling</a>", <i>IEEE Trans. Inform. Theory</i>, vol. 65, pp. 3630-3645, June 2019.'
---
