---
title: "Uniform Recovery Bounds for Structured Random Matrices in Corrupted Compressed Sensing"
collection: publications
category: manuscripts
permalink: /publication/2018-04-01-zhang-uniform-recovery
date: 2018-04-01
venue: 'IEEE Trans. Signal Processing'
paperurl: 'https://arxiv.org/abs/1706.09087'
citation: 'Peng Zhang, Lu Gan, Cong Ling, Sumei Sun. "<a href="https://arxiv.org/abs/1706.09087">Uniform Recovery Bounds for Structured Random Matrices in Corrupted Compressed Sensing</a>", <i>IEEE Trans. Signal Processing</i>, vol. 66, pp. 2086-2097, Apr. 2018.'
---
