---
title: "Active physical-layer network coding for cooperative two-way relay channels"
collection: publications
category: conferences
permalink: /publication/2009-01-01-active-physical-layer-network-coding-for-cooperative-two-way-relay-channels
date: 2009-01-01
venue: 'Second IEEE International Workshop on Wireless Network Coding'
paperurl: ''
citation: 'Haishi Ning, Cong Ling and Kin Leung "<a href=''>Active physical-layer network coding for cooperative two-way relay channels</a>", Second IEEE International Workshop on Wireless Network Coding, Rome, Italy, 2009.'
---
