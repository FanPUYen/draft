---
title: "On SOVA for nonbinary codes"
collection: publications
category: manuscripts
permalink: /publication/1999-01-01-on-sova-for-nonbinary-codes
date: 1999-01-01
venue: 'IEEE Commun. Lett.'
paperurl: ''
citation: 'Ling Cong, Wu Xiaofu and Yi Xiaoxin "<a href=''>On SOVA for nonbinary codes</a>", IEEE Commun. Lett., vol. 3, pp. 335-337, Dec. 1999.'
---
