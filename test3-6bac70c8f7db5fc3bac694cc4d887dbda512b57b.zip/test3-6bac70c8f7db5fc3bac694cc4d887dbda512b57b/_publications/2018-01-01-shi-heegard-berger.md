---
title: "Polar Codes and Polar Lattices for the Heegard-Berger Problem"
collection: publications
category: manuscripts
permalink: /publication/2018-01-01-shi-heegard-berger
date: 2018-01-01
venue: 'IEEE Trans. Commun.'
paperurl: 'https://arxiv.org/abs/1702.01042'
citation: 'Jinwen Shi, Ling Liu, Deniz Gündüz, Cong Ling. "<a href="https://arxiv.org/abs/1702.01042">Polar Codes and Polar Lattices for the Heegard-Berger Problem</a>", <i>IEEE Trans. Commun.</i>, 2018.'
---
