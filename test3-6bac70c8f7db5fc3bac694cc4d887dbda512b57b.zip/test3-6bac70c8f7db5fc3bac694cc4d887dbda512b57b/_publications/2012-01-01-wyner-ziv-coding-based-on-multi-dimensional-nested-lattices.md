---
title: "Wyner-Ziv coding based on multi-dimensional nested lattices"
collection: publications
category: manuscripts
permalink: /publication/2012-01-01-wyner-ziv-coding-based-on-multi-dimensional-nested-lattices
date: 2012-01-01
venue: 'IEEE Trans. Commun.'
paperurl: 'http://arxiv.org/abs/1111.1347'
citation: 'Cong Ling, Su Gao, and Jean-Claude Belfiore "<a href="http://arxiv.org/abs/1111.1347">Wyner-Ziv coding based on multi-dimensional nested lattices</a>", IEEE Trans. Commun., vol. 60, pp.1328-1335, May 2012.'
---
