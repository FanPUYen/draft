---
title: "Effect of correlated Nakagami-m fading on the e-outage channel capacity of the decentralized two-relay network"
collection: publications
category: manuscripts
permalink: /publication/2010-01-01-effect-of-correlated-nakagami-m-fading-on-the-e-outage-channel-capacity-of-the-decentralized-two-relay-network
date: 2010-01-01
venue: 'IEEE Trans. Wireless. Commun.'
paperurl: ''
citation: 'Yifan Chen and Cong Ling "<a href=''>Effect of correlated Nakagami-m fading on the e-outage channel capacity of the decentralized two-relay network</a>", IEEE Trans. Wireless. Commun., vol. 9, pp. 3607-3612, Dec. 2010.'
---
