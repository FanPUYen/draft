---
title: "Gallager bounds for space-time codes"
collection: publications
category: conferences
permalink: /publication/2004-01-01-gallager-bounds-for-space-time-codes
date: 2004-01-01
venue: 'IEEE Communication Theory Workshop 2004'
paperurl: ''
citation: 'Cong Ling, K. H. Li and A. C. Kot "<a href=''>Gallager bounds for space-time codes</a>", IEEE Communication Theory Workshop 2004, Capri, Italy, May 2004.'
---
