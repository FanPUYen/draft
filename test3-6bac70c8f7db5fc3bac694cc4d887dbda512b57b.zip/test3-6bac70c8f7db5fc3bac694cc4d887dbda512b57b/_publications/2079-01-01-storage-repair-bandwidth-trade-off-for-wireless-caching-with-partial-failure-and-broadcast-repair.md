---
title: "Storage-repair bandwidth trade-off for wireless caching with partial failure and broadcast repair"
collection: publications
category: conferences
permalink: /publication/2079-01-01-storage-repair-bandwidth-trade-off-for-wireless-caching-with-partial-failure-and-broadcast-repair
date: 2079-01-01
venue: '2018 IEEE Information Theory Workshop (ITW)'
paperurl: 'https://ieeexplore.ieee.org/abstract/document/8613401'
citation: 'Nitish Mital, Katina Kralevska, Cong Ling, Deniz Gündüz. "<a href="https://ieeexplore.ieee.org/abstract/document/8613401">Storage-repair bandwidth trade-off for wireless caching with partial failure and broadcast repair</a>", <i>2018 IEEE Information Theory Workshop (ITW)</i>, pp. 1--5, Jan. 2079.'
---
