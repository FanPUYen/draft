---
title: "Integration of GPS with a WiFi high accuracy ranging functionality"
collection: publications
category: manuscripts
permalink: /publication/2013-01-01-integration-of-gps-with-a-wifi-high-accuracy-ranging-functionality
date: 2013-01-01
venue: 'Geo-spatial Information Science'
paperurl: ''
citation: 'K Nur, S. Fenga, C. Ling and W. Ochieng "<a href=''>Integration of GPS with a WiFi high accuracy ranging functionality</a>", Geo-spatial Information Science, vol. 16, no. 3, pp. 155-168, 2013.'
---
