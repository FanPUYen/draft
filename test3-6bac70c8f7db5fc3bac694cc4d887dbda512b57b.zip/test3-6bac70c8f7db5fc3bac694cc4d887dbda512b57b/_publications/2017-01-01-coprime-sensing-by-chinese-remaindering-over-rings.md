---
title: "Coprime Sensing by Chinese Remaindering over Rings"
collection: publications
category: manuscripts
permalink: /publication/2017-01-01-coprime-sensing-by-chinese-remaindering-over-rings
date: 2017-01-01
venue: 'SAMPTA 2017.'
paperurl: ''
citation: 'Conghui Li, Lu Gan and Cong Ling "<a href=''>Coprime Sensing by Chinese Remaindering over Rings</a>", SAMPTA 2017.'
---
