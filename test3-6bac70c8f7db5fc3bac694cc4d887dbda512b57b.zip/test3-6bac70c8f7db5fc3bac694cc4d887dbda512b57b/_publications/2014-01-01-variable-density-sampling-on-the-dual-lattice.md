---
title: "Variable-Density Sampling on the Dual Lattice"
collection: publications
category: conferences
permalink: /publication/2014-01-01-variable-density-sampling-on-the-dual-lattice
date: 2014-01-01
venue: 'ISIT 2014.'
paperurl: ''
citation: 'Peng Zhang, Sumei Sun, and Cong Ling "<a href=''>Variable-Density Sampling on the Dual Lattice</a>", ISIT 2014.'
---
