---
title: "Bounds on the decoding error probability of binary block codes over noncoherent block AWGN and fading channels"
collection: publications
category: manuscripts
permalink: /publication/2006-01-01-bounds-on-the-decoding-error-probability-of-binary-block-codes-over-noncoherent-block-awgn-and-fading-channels
date: 2006-01-01
venue: 'IEEE Trans. Wireless Commun.'
paperurl: ''
citation: 'Xiaofu Wu, Haige Xiang, Cong Ling, Xiaohu You, and Shaoqian Li "<a href=''>Bounds on the decoding error probability of binary block codes over noncoherent block AWGN and fading channels</a>", IEEE Trans. Wireless Commun., vol. 5, pp. 3193-3203, Nov. 2006.'
---
