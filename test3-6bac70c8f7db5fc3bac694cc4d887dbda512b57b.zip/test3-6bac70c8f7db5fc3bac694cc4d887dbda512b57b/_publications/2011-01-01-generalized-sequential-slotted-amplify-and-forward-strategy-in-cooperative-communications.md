---
title: "Generalized sequential slotted amplify and forward strategy in cooperative communications"
collection: publications
category: manuscripts
permalink: /publication/2011-01-01-generalized-sequential-slotted-amplify-and-forward-strategy-in-cooperative-communications
date: 2011-01-01
venue: 'IEEE Trans. Inform. Theory'
paperurl: ''
citation: 'Haishi Ning, Cong Ling, and Kin. K. Leung "<a href=''>Generalized sequential slotted amplify and forward strategy in cooperative communications</a>", IEEE Trans. Inform. Theory, vol. 57, pp. 1968-1974, Apr. 2011.'
---
