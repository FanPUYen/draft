---
title: "Deterministic compressed-sensing matrices: Where Toeplitz meets Golay"
collection: publications
category: manuscripts
permalink: /publication/2011-01-01-deterministic-compressed-sensing-matrices-where-toeplitz-meets-golay
date: 2011-01-01
venue: 'IEEE ICASSP 2011'
paperurl: ''
citation: 'Kezhi Li, Cong Ling and Lu Gan "<a href=''>Deterministic compressed-sensing matrices: Where Toeplitz meets Golay</a>", IEEE ICASSP 2011, Prague, Czech.'
---
