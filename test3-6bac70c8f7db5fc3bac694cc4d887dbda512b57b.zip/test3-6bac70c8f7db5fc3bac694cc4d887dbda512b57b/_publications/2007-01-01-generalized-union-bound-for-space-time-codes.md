---
title: "Generalized union bound for space-time codes"
collection: publications
category: manuscripts
permalink: /publication/2007-01-01-generalized-union-bound-for-space-time-codes
date: 2007-01-01
venue: 'IEEE Trans. Commun.'
paperurl: ''
citation: 'Cong Ling "<a href=''>Generalized union bound for space-time codes</a>", IEEE Trans. Commun., vol. 55, pp. 90-99, Jan. 2007.'
---
