---
title: "Multisampling decision-feedback linear prediction receivers for differential space-time modulation over Rayleigh fast fading channels"
collection: publications
category: manuscripts
permalink: /publication/2003-01-01-multisampling-decision-feedback-linear-prediction-receivers-for-differential-space-time-modulation-over-rayleigh-fast-fading-channels
date: 2003-01-01
venue: 'IEEE Trans. Commun.'
paperurl: ''
citation: 'Cong Ling, K. H. Li, A. C. Kot, and Q. T. Zhang "<a href=''>Multisampling decision-feedback linear prediction receivers for differential space-time modulation over Rayleigh fast fading channels</a>", IEEE Trans. Commun., vol. 51, pp. 1214-1223, July 2003.'
---
