---
title: "Achieving Capacity and Security in Wireless Communications With Lattice Codes"
collection: publications
category: conferences
permalink: /publication/2016-01-01-achieving-capacity-and-security-in-wireless-communications-with-lattice-codes
date: 2016-01-01
venue: 'International Symposium on Turbo Codes 2016.'
paperurl: ''
citation: 'Cong Ling "<a href=''>Achieving Capacity and Security in Wireless Communications With Lattice Codes</a>",  International Symposium on Turbo Codes 2016.'
---
