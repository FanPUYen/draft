---
title: "Semantically Secure Lattice Codes for Compound MIMO Channels"
collection: publications
category: manuscripts
permalink: /publication/2020-03-01-campello-sem-secure-compound-mimo
date: 2020-03-01
venue: 'IEEE Trans. Inform. Theory'
paperurl: ''
citation: 'Antonio Campello, Cong Ling, Jean-Claude Belfiore. "Semantically Secure Lattice Codes for Compound MIMO Channels", <i>IEEE Trans. Inform. Theory</i>, vol. 66, pp. 1572-1584, Mar. 2020.'
---
