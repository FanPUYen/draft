---
title: "Efficient Integer Coefficient Search for Compute-and-Forward"
collection: publications
category: manuscripts
permalink: /publication/2016-01-01-efficient-integer-coefficient-search-for-compute-and-forward
date: 2016-01-01
venue: 'IEEE Trans. Wireless Commun.'
paperurl: 'https://arxiv.org/abs/1609.05490'
citation: 'William Liu and Cong Ling "<a href="https://arxiv.org/abs/1609.05490">Efficient Integer Coefficient Search for Compute-and-Forward</a>", IEEE Trans. Wireless Commun., vol. 15, pp. 8039-8050, Dec. 2016.'
---
