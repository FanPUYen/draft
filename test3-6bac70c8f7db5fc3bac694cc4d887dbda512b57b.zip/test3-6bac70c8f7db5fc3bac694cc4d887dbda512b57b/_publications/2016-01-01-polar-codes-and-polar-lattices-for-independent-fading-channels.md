---
title: "Polar Codes and Polar Lattices for Independent Fading Channels"
collection: publications
category: manuscripts
permalink: /publication/2016-01-01-polar-codes-and-polar-lattices-for-independent-fading-channels
date: 2016-01-01
venue: 'IEEE Trans. Commun.'
paperurl: 'https://arxiv.org/abs/1601.04967'
citation: 'Ling Liu and Cong Ling "<a href="https://arxiv.org/abs/1601.04967">Polar Codes and Polar Lattices for Independent Fading Channels</a>", IEEE Trans. Commun., vol. 64, pp. 4923-4935, Dec. 2016.'
---
