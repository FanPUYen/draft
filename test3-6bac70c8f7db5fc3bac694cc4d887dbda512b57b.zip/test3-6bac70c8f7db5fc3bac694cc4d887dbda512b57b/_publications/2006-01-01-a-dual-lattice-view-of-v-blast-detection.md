---
title: "A dual-lattice view of V-BLAST detection"
collection: publications
category: conferences
permalink: /publication/2006-01-01-a-dual-lattice-view-of-v-blast-detection
date: 2006-01-01
venue: 'IEEE Inform. Theory Workshop'
paperurl: ''
citation: 'Cong Ling, Lu Gan, and Wai Ho Mow "<a href=''>A dual-lattice view of V-BLAST detection</a>", IEEE Inform. Theory Workshop, Chengdu, China, Oct. 2006.'
---
