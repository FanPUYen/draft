---
title: "On the equivalence between probabilistic shaping and geometric shaping: a polar lattice perspective"
collection: publications
category: conferences
permalink: /publication/2024-01-01-on-the-equivalence-between-probabilistic-shaping-and-geometric-shaping-a-polar-lattice-perspective
date: 2024-01-01
venue: '2024 IEEE International Symposium on Information Theory (ISIT)'
paperurl: 'https://ieeexplore.ieee.org/document/10619275'
citation: 'Ling Liu, Shanxiang Lyu, Cong Ling, Baoming Bai. "<a href="https://ieeexplore.ieee.org/document/10619275">On the equivalence between probabilistic shaping and geometric shaping: a polar lattice perspective</a>", <i>2024 IEEE International Symposium on Information Theory (ISIT)</i>, pp. 2174--2179, Jan. 2024.'
---
