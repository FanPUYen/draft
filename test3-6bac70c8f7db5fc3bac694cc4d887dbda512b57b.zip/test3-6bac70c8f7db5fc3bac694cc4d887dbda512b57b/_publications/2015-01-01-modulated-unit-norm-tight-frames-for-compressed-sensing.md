---
title: "Modulated Unit-Norm Tight Frames for Compressed Sensing"
collection: publications
category: manuscripts
permalink: /publication/2015-01-01-modulated-unit-norm-tight-frames-for-compressed-sensing
date: 2015-01-01
venue: 'IEEE Trans. Signal Processing'
paperurl: 'http://arxiv.org/abs/1411.7630'
citation: 'Peng Zhang, Lu Gan, Sumei Sun, and Cong Ling "<a href="http://arxiv.org/abs/1411.7630">Modulated Unit-Norm Tight Frames for Compressed Sensing</a>", IEEE Trans. Signal Processing, vol. 63, no. 15, pp. 3974–3985, August 2015.'
---
