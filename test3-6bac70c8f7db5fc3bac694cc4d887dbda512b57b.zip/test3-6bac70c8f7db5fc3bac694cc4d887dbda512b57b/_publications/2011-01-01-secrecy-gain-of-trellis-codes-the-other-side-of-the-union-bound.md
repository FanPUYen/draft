---
title: "Secrecy gain of trellis codes: The other side of the union bound"
collection: publications
category: conferences
permalink: /publication/2011-01-01-secrecy-gain-of-trellis-codes-the-other-side-of-the-union-bound
date: 2011-01-01
venue: 'ITW 2011'
paperurl: ''
citation: 'Yanfei Yan, Cong Ling and Jean-Claude Belfiore "<a href=''>Secrecy gain of trellis codes: The other side of the union bound</a>", ITW 2011, Paraty, Brasil, Oct. 2011.'
---
