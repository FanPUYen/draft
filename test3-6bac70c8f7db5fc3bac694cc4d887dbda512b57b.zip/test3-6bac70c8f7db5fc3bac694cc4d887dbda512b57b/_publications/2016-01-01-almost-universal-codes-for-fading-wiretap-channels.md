---
title: "Almost universal codes for fading wiretap channels"
collection: publications
category: conferences
permalink: /publication/2016-01-01-almost-universal-codes-for-fading-wiretap-channels
date: 2016-01-01
venue: 'ISIT 2016.'
paperurl: 'http://arxiv.org/abs/1601.02391'
citation: 'L. Luzzi, C. Ling and R. Vehkalahti "<a href="http://arxiv.org/abs/1601.02391">Almost universal codes for fading wiretap channels</a>", ISIT 2016.'
---
