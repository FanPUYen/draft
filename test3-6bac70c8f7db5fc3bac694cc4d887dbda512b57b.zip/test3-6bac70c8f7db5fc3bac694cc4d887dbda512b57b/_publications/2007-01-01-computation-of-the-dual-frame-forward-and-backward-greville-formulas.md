---
title: "Computation of the dual frame: Forward and backward Greville formulas"
collection: publications
category: manuscripts
permalink: /publication/2007-01-01-computation-of-the-dual-frame-forward-and-backward-greville-formulas
date: 2007-01-01
venue: 'IEEE ICASSP 2007.'
paperurl: ''
citation: 'Lu Gan and Cong Ling "<a href=''>Computation of the dual frame: Forward and backward Greville formulas</a>", IEEE ICASSP 2007.'
---
