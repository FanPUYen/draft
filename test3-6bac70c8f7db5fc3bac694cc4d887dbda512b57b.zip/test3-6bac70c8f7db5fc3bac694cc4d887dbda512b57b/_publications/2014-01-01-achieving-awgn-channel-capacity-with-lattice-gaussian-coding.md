---
title: "Achieving AWGN channel capacity with lattice Gaussian coding"
collection: publications
category: manuscripts
permalink: /publication/2014-01-01-achieving-awgn-channel-capacity-with-lattice-gaussian-coding
date: 2014-01-01
venue: 'IEEE Trans. Inform. Theory'
paperurl: 'http://arxiv.org/abs/1302.5906'
citation: 'Cong Ling and Jean-Claude Belfiore "<a href="http://arxiv.org/abs/1302.5906">Achieving AWGN channel capacity with lattice Gaussian coding</a>", IEEE Trans. Inform. Theory, vol. 60, no. 10, pp. 5918–5929, Oct. 2014.'
---
