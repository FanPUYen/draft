---
title: "MIMO Broadcasting for Simultaneous Wireless Information and Power Transfer: Weighted MMSE Approaches"
collection: publications
category: conferences
permalink: /publication/2014-01-01-mimo-broadcasting-for-simultaneous-wireless-information-and-power-transfer-weighted-mmse-approaches
date: 2014-01-01
venue: 'Globecom 2014.'
paperurl: 'http://arxiv.org/abs/1410.4360'
citation: 'Changick Song, Cong Ling, Jaehyun Park, Bruno Clerckx "<a href="http://arxiv.org/abs/1410.4360">MIMO Broadcasting for Simultaneous Wireless Information and Power Transfer: Weighted MMSE Approaches</a>", Globecom 2014.'
---
