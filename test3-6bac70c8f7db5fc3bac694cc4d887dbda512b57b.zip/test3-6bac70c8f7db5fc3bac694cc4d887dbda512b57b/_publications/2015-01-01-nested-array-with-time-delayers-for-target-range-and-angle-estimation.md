---
title: "Nested Array With Time-Delayers for Target Range and Angle Estimation"
collection: publications
category: conferences
permalink: /publication/2015-01-01-nested-array-with-time-delayers-for-target-range-and-angle-estimation
date: 2015-01-01
venue: '3rd International Workshop on Compressed Sensing Theory and its Applications to Radar'
paperurl: ''
citation: 'Wen-Qin Wang and Cong Ling "<a href=''>Nested Array With Time-Delayers for Target Range and Angle Estimation</a>", 3rd International Workshop on Compressed Sensing Theory and its Applications to Radar, Sonar, and Remote Sensing (CoSeRa) 2015.'
---
