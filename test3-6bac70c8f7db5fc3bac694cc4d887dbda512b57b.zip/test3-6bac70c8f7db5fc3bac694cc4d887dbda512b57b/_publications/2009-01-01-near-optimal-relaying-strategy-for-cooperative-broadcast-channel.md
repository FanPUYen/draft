---
title: "Near-optimal relaying strategy for cooperative broadcast channel"
collection: publications
category: conferences
permalink: /publication/2009-01-01-near-optimal-relaying-strategy-for-cooperative-broadcast-channel
date: 2009-01-01
venue: 'ICC’09'
paperurl: ''
citation: 'Haishi Ning, Cong Ling and Kin Leung "<a href=''>Near-optimal relaying strategy for cooperative broadcast channel</a>", ICC’09, Dresden, Germany.'
---
