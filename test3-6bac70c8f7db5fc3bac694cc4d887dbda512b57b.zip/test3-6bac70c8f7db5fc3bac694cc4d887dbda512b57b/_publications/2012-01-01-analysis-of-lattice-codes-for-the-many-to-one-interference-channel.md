---
title: "Analysis of lattice codes for the many-to-one interference channel"
collection: publications
category: conferences
permalink: /publication/2012-01-01-analysis-of-lattice-codes-for-the-many-to-one-interference-channel
date: 2012-01-01
venue: 'IEEE Inform. Theory Workshop 2012.'
paperurl: ''
citation: 'Maria Estela, Laura Luzzi, Cong Ling and Jean-Claude Belfiore "<a href=''>Analysis of lattice codes for the many-to-one interference channel</a>", IEEE Inform. Theory Workshop 2012.'
---
