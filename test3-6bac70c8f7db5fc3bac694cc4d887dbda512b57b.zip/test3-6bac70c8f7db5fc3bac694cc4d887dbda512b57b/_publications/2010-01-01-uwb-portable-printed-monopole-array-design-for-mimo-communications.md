---
title: "UWB portable printed monopole array design for MIMO communications"
collection: publications
category: manuscripts
permalink: /publication/2010-01-01-uwb-portable-printed-monopole-array-design-for-mimo-communications
date: 2010-01-01
venue: 'Microwave and Optical Technology Letters'
paperurl: ''
citation: 'Daniel Valderas, Cong Ling, and Pedro Crespo "<a href=''>UWB portable printed monopole array design for MIMO communications</a>", Microwave and Optical Technology Letters, vol. 52, pp. 889-895, Apr. 2010.'
---
