---
title: "A small serving of mash:(Quantum) algorithms for SPDH-Sign with small parameters"
collection: publications
category: manuscripts
permalink: /publication/2025-01-01-a-small-serving-of-mash-quantum-algorithms-for-spdh-sign-with-small-parameters
date: 2025-01-01
venue: 'Journal of Mathematical Cryptology'
paperurl: 'https://www.degruyterbrill.com/document/doi/10.1515/jmc-2024-0025/html'
citation: 'Andrew Mendelsohn, Edmund Dable-Heath, Cong Ling. "<a href="https://www.degruyterbrill.com/document/doi/10.1515/jmc-2024-0025/html">A small serving of mash:(Quantum) algorithms for SPDH-Sign with small parameters</a>", <i>Journal of Mathematical Cryptology</i>, vol. 19, no. 1, pp. 20240025, Jan. 2025.'
---
