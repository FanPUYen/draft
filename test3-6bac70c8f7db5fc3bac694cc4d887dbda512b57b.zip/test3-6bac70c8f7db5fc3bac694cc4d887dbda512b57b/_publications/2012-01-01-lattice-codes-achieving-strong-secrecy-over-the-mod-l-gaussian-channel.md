---
title: "Lattice codes achieving strong secrecy over the mod-L Gaussian channel"
collection: publications
category: conferences
permalink: /publication/2012-01-01-lattice-codes-achieving-strong-secrecy-over-the-mod-l-gaussian-channel
date: 2012-01-01
venue: 'ISIT 2012.'
paperurl: ''
citation: 'C. Ling, L. Luzzi, and J.-C. Belfiore "<a href=''>Lattice codes achieving strong secrecy over the mod-L Gaussian channel</a>", ISIT 2012.'
---
