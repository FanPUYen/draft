---
title: "2D MIMO Radar with Coprime Arrays"
collection: publications
category: manuscripts
permalink: /publication/2018-01-01-2d-mimo-radar-with-coprime-arrays
date: 2018-01-01
venue: 'SAM 2018.'
paperurl: ''
citation: 'Conghui Li, Lu Gan and Cong Ling "<a href=''>2D MIMO Radar with Coprime Arrays</a>", SAM 2018.'
---
