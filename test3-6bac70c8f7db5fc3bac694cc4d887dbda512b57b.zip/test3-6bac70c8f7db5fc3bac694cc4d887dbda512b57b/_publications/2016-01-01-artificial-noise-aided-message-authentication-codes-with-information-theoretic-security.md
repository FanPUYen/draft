---
title: "Artificial-Noise-Aided Message Authentication Codes with Information-Theoretic Security"
collection: publications
category: manuscripts
permalink: /publication/2016-01-01-artificial-noise-aided-message-authentication-codes-with-information-theoretic-security
date: 2016-01-01
venue: 'IEEE Trans. Inform. Forensics & Security'
paperurl: 'http://arxiv.org/abs/1511.05357'
citation: 'Xiaofu Wu, Zhen Yang, Cong Ling, Xiang-Gen Xia "<a href="http://arxiv.org/abs/1511.05357">Artificial-Noise-Aided Message Authentication Codes with Information-Theoretic Security</a>", IEEE Trans. Inform. Forensics & Security, vol. 11, no. 6, pp. 1278–1290, Jan. 2016.'
---
