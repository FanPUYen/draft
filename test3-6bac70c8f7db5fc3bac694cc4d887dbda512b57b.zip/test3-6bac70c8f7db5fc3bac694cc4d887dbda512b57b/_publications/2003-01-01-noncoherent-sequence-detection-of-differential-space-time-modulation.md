---
title: "Noncoherent sequence detection of differential space-time modulation"
collection: publications
category: manuscripts
permalink: /publication/2003-01-01-noncoherent-sequence-detection-of-differential-space-time-modulation
date: 2003-01-01
venue: 'IEEE Trans. Inform. Theory'
paperurl: ''
citation: 'Cong Ling, K. H. Li and A. C. Kot "<a href=''>Noncoherent sequence detection of differential space-time modulation</a>", IEEE Trans. Inform. Theory, vol.49, pp. 2727-2734, Oct. 2003.'
---
