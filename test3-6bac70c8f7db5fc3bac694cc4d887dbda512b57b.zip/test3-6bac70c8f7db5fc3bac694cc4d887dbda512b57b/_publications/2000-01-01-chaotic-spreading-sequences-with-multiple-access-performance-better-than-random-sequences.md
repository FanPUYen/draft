---
title: "Chaotic spreading sequences with multiple access performance better than random sequences"
collection: publications
category: manuscripts
permalink: /publication/2000-01-01-chaotic-spreading-sequences-with-multiple-access-performance-better-than-random-sequences
date: 2000-01-01
venue: 'IEEE Trans. CAS-I'
paperurl: ''
citation: 'Ling Cong and Li Shaoqian "<a href=''>Chaotic spreading sequences with multiple access performance better than random sequences</a>", IEEE Trans. CAS-I, vol. 47, pp. 394-397, Mar. 2000.'
---
