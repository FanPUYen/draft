---
title: "Further Results on Independent Metropolis-Hastings-Klein Sampling"
collection: publications
category: conferences
permalink: /publication/2016-01-01-further-results-on-independent-metropolis-hastings-klein-sampling
date: 2016-01-01
venue: 'ISIT 2016.'
paperurl: ''
citation: 'Zheng Wang and Cong Ling "<a href=''>Further Results on Independent Metropolis-Hastings-Klein Sampling</a>", ISIT 2016.'
---
