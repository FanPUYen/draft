---
title: "Construction of Simultaneously Good Polar Codes and Polar Lattices"
collection: publications
category: manuscripts
permalink: /publication/2025-01-01-construction-of-simultaneously-good-polar-codes-and-polar-lattices
date: 2025-01-01
venue: 'arXiv preprint arXiv:2501.11931'
paperurl: 'https://arxiv.org/pdf/2501.11931'
citation: 'Ling Liu, Ruimin Yuan, Shanxiang Lyu, Cong Ling, Baoming Bai. "<a href="https://arxiv.org/pdf/2501.11931">Construction of Simultaneously Good Polar Codes and Polar Lattices</a>", <i>arXiv preprint arXiv:2501.11931</i>, Jan. 2025.'
---
