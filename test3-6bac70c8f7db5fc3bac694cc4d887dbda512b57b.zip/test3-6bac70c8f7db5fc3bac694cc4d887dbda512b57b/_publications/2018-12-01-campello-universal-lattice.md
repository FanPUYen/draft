---
title: "Universal Lattice Codes for MIMO Channels"
collection: publications
category: manuscripts
permalink: /publication/2018-12-01-campello-universal-lattice
date: 2018-12-01
venue: 'IEEE Trans. Inform. Theory'
paperurl: 'https://arxiv.org/abs/1603.09263'
citation: 'Antonio Campello, Cong Ling, Jean-Claude Belfiore. "<a href="https://arxiv.org/abs/1603.09263">Universal Lattice Codes for MIMO Channels</a>", <i>IEEE Trans. Inform. Theory</i>, vol. 64, pp. 7847-7865, Dec. 2018.'
---
