---
title: "Independent Metropolis-Hastings-Klein Algorithm for Lattice Gaussian Sampling"
collection: publications
category: conferences
permalink: /publication/2015-01-01-independent-metropolis-hastings-klein-algorithm-for-lattice-gaussian-sampling
date: 2015-01-01
venue: 'ISIT 2015.'
paperurl: 'http://arxiv.org/abs/1501.05757'
citation: 'Zheng Wang and Cong Ling "<a href="http://arxiv.org/abs/1501.05757">Independent Metropolis-Hastings-Klein Algorithm for Lattice Gaussian Sampling</a>", ISIT 2015.'
---
