---
title: "Greedy user selection using a lattice reduction updating method for multiuser MIMO systems"
collection: publications
category: manuscripts
permalink: /publication/2011-01-01-greedy-user-selection-using-a-lattice-reduction-updating-method-for-multiuser-mimo-systems
date: 2011-01-01
venue: 'IEEE Trans. Vehicular Tech.'
paperurl: ''
citation: 'L. Bai, C. Chen, J. Choi, and C. Ling "<a href=''>Greedy user selection using a lattice reduction updating method for multiuser MIMO systems</a>", IEEE Trans. Vehicular Tech., vol. 60, pp. 136-147, Jan. 2011.'
---
