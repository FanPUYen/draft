---
title: "Lattice Gaussian Coding for Capacity and Secrecy: Two Sides of One Coin"
collection: publications
category: conferences
permalink: /publication/2014-01-01-lattice-gaussian-coding-for-capacity-and-secrecy-two-sides-of-one-coin
date: 2014-01-01
venue: 'International Zurich Seminar on Communications 2014 (invited paper).'
paperurl: ''
citation: 'Cong Ling and Jean-Claude Belfiore "<a href=''>Lattice Gaussian Coding for Capacity and Secrecy: Two Sides of One Coin</a>", International Zurich Seminar on Communications 2014 (invited paper).'
---
