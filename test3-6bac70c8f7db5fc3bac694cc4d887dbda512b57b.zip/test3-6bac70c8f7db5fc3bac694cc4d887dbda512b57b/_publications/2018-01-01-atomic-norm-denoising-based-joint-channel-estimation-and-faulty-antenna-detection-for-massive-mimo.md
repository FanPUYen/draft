---
title: "Atomic Norm Denoising-Based Joint Channel Estimation and Faulty Antenna Detection for Massive MIMO"
collection: publications
category: manuscripts
permalink: /publication/2018-01-01-atomic-norm-denoising-based-joint-channel-estimation-and-faulty-antenna-detection-for-massive-mimo
date: 2018-01-01
venue: 'IEEE Trans. Veh. Tech.'
paperurl: 'https://arxiv.org/abs/1709.06832'
citation: 'Peng Zhang, Lu Gan, Cong Ling, and Sumei Sun "<a href="https://arxiv.org/abs/1709.06832">Atomic Norm Denoising-Based Joint Channel Estimation and Faulty Antenna Detection for Massive MIMO</a>", IEEE Trans. Veh. Tech., vol. 67, pp. 1389-1403, Feb. 2018.'
---
