---
title: "Novel Toeptlitz sensing matrices for compressive radar imaging"
collection: publications
category: conferences
permalink: /publication/2012-01-01-novel-toeptlitz-sensing-matrices-for-compressive-radar-imaging
date: 2012-01-01
venue: '1st International Workshop on Compressed Sensing applied to Radar'
paperurl: ''
citation: 'Lu Gan, Kezhi Li, and Cong Ling "<a href=''>Novel Toeptlitz sensing matrices for compressive radar imaging</a>", 1st International Workshop on Compressed Sensing applied to Radar, 2012, Bonn, Germany.'
---
