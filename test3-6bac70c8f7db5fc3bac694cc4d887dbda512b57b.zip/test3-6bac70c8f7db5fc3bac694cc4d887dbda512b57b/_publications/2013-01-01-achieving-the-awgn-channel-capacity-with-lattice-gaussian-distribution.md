---
title: "Achieving the AWGN channel capacity with lattice Gaussian distribution"
collection: publications
category: conferences
permalink: /publication/2013-01-01-achieving-the-awgn-channel-capacity-with-lattice-gaussian-distribution
date: 2013-01-01
venue: 'ISIT 2013.'
paperurl: ''
citation: 'Cong Ling and Jean-Claude Belfiore "<a href=''>Achieving the AWGN channel capacity with lattice Gaussian distribution</a>", ISIT 2013.'
---
