---
title: "Not-so-adiabatic quantum computation for the shortest vector problem"
collection: publications
category: manuscripts
permalink: /publication/2020-01-01-joseph-not-so-adiabatic-svp
date: 2020-01-01
venue: 'Physical Review Research'
paperurl: ''
citation: 'David Joseph, Alexandros Ghionis, Cong Ling, Florian Mintert. "Not-so-adiabatic quantum computation for the shortest vector problem", <i>Physical Review Research</i>, Vol. 2, 013361, 2020.'
---
