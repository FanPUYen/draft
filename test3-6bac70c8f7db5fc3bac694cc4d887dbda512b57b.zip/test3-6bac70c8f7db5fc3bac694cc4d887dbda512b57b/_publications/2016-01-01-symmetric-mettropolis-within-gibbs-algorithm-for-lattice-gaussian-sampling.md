---
title: "Symmetric Mettropolis-within-Gibbs Algorithm for Lattice Gaussian Sampling"
collection: publications
category: conferences
permalink: /publication/2016-01-01-symmetric-mettropolis-within-gibbs-algorithm-for-lattice-gaussian-sampling
date: 2016-01-01
venue: 'ITW 2016.'
paperurl: ''
citation: 'Zheng Wang and Cong Ling "<a href=''>Symmetric Mettropolis-within-Gibbs Algorithm for Lattice Gaussian Sampling</a>",  ITW 2016.'
---
