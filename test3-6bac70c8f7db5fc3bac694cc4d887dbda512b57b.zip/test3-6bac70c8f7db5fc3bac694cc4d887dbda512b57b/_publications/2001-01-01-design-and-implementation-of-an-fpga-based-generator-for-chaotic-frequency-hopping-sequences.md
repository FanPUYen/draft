---
title: "Design and implementation of an FPGA-based generator for chaotic frequency hopping sequences"
collection: publications
category: manuscripts
permalink: /publication/2001-01-01-design-and-implementation-of-an-fpga-based-generator-for-chaotic-frequency-hopping-sequences
date: 2001-01-01
venue: 'IEEE Trans. CAS-I'
paperurl: ''
citation: 'Ling Cong and Wu Xiaofu "<a href=''>Design and implementation of an FPGA-based generator for chaotic frequency hopping sequences</a>", IEEE Trans. CAS-I, vol. 48, pp. 521-532, May 2001.'
---
