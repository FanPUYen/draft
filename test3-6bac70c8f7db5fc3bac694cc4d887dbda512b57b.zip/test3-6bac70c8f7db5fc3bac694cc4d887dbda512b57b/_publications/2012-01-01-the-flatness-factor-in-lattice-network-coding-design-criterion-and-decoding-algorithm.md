---
title: "The flatness factor in lattice network coding: Design criterion and decoding algorithm"
collection: publications
category: conferences
permalink: /publication/2012-01-01-the-flatness-factor-in-lattice-network-coding-design-criterion-and-decoding-algorithm
date: 2012-01-01
venue: 'International Zurich Seminar on Communications 2012'
paperurl: ''
citation: 'J.-C. Belfiore and Cong Ling "<a href=''>The flatness factor in lattice network coding: Design criterion and decoding algorithm</a>", International Zurich Seminar on Communications 2012, invited paper.'
---
