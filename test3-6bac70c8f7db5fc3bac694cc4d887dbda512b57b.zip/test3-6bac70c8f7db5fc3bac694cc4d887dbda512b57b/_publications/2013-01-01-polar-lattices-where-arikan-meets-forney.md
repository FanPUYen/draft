---
title: "Polar lattices: Where Arikan meets Forney"
collection: publications
category: conferences
permalink: /publication/2013-01-01-polar-lattices-where-arikan-meets-forney
date: 2013-01-01
venue: 'ISIT 2013.'
paperurl: ''
citation: 'Yanfei Yan, Cong Ling and Xiaofu Wu "<a href=''>Polar lattices: Where Arikan meets Forney</a>", ISIT 2013.'
---
