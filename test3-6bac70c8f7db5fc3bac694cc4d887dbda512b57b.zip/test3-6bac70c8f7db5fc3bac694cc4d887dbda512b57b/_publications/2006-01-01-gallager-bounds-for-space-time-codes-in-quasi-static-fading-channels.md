---
title: "Gallager bounds for space-time codes in quasi-static fading channels"
collection: publications
category: conferences
permalink: /publication/2006-01-01-gallager-bounds-for-space-time-codes-in-quasi-static-fading-channels
date: 2006-01-01
venue: 'IEEE Inform. Theory Workshop'
paperurl: ''
citation: 'Cong Ling "<a href=''>Gallager bounds for space-time codes in quasi-static fading channels</a>", IEEE Inform. Theory Workshop, Oct. 2006.'
---
