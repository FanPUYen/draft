---
title: "Construction $\pi_A$ Lattices Extended to Hurwitz Quaternion Integers"
collection: publications
category: conferences
permalink: /publication/2024-01-01-construction-pi-a-lattices-extended-to-hurwitz-quaternion-integers
date: 2024-01-01
venue: '2024 IEEE International Symposium on Information Theory (ISIT)'
paperurl: 'https://ieeexplore.ieee.org/abstract/document/10619280'
citation: 'Juliana G. F. Souza, Sueli I. R. Costa, Cong Ling. "<a href="https://ieeexplore.ieee.org/abstract/document/10619280">Construction $\pi_A$ Lattices Extended to Hurwitz Quaternion Integers</a>", <i>2024 IEEE International Symposium on Information Theory (ISIT)</i>, pp. 2186-2191, Jan. 2024.'
---
