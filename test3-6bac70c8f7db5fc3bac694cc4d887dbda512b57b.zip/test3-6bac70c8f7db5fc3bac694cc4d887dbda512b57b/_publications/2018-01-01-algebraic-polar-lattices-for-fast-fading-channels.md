---
title: "Algebraic Polar Lattices for Fast Fading Channels"
collection: publications
category: manuscripts
permalink: /publication/2018-01-01-algebraic-polar-lattices-for-fast-fading-channels
date: 2018-01-01
venue: 'ISTC 2018.'
paperurl: ''
citation: 'Ling Liu and Cong Ling "<a href=''>Algebraic Polar Lattices for Fast Fading Channels</a>", ISTC 2018.'
---
