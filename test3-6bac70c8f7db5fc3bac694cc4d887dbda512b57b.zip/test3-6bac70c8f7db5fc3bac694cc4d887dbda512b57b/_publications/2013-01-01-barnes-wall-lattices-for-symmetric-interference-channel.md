---
title: "Barnes-Wall lattices for symmetric interference channel"
collection: publications
category: conferences
permalink: /publication/2013-01-01-barnes-wall-lattices-for-symmetric-interference-channel
date: 2013-01-01
venue: 'ISIT 2013.'
paperurl: ''
citation: 'Maria Estela, Cong Ling and Jean-Claude Belfiore "<a href=''>Barnes-Wall lattices for symmetric interference channel</a>", ISIT 2013.'
---
