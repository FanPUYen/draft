---
title: "Performance evaluation for bandlimited DS-CDMA systems based on simplified improved Gaussian approximation"
collection: publications
category: manuscripts
permalink: /publication/2003-01-01-performance-evaluation-for-bandlimited-ds-cdma-systems-based-on-simplified-improved-gaussian-approximation
date: 2003-01-01
venue: 'IEEE Trans. Commun.'
paperurl: ''
citation: 'Guozhen Zang and Cong Ling "<a href=''>Performance evaluation for bandlimited DS-CDMA systems based on simplified improved Gaussian approximation</a>", IEEE Trans. Commun., vol. 51, pp. 1204-1213, July 2003.'
---
