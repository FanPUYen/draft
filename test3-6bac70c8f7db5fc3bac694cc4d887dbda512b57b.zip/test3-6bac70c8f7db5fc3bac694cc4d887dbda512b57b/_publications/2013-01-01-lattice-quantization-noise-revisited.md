---
title: "Lattice quantization noise revisited"
collection: publications
category: conferences
permalink: /publication/2013-01-01-lattice-quantization-noise-revisited
date: 2013-01-01
venue: 'IEEE Inform. Theory Workshop 2013.'
paperurl: ''
citation: 'Cong Ling and Lu Gan "<a href=''>Lattice quantization noise revisited</a>", IEEE Inform. Theory Workshop 2013.'
---
