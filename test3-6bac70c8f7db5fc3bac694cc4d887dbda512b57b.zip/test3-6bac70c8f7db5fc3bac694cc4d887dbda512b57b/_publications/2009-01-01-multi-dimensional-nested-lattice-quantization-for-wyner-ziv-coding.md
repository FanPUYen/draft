---
title: "Multi-dimensional nested lattice quantization for Wyner-Ziv coding"
collection: publications
category: conferences
permalink: /publication/2009-01-01-multi-dimensional-nested-lattice-quantization-for-wyner-ziv-coding
date: 2009-01-01
venue: 'ICC’09'
paperurl: ''
citation: 'Su Gao and Cong Ling "<a href=''>Multi-dimensional nested lattice quantization for Wyner-Ziv coding</a>", ICC’09, Dresden, Germany.'
---
