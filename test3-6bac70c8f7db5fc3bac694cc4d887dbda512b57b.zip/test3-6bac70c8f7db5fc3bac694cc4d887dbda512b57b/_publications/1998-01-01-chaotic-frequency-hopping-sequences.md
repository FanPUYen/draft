---
title: "Chaotic frequency hopping sequences"
collection: publications
category: manuscripts
permalink: /publication/1998-01-01-chaotic-frequency-hopping-sequences
date: 1998-01-01
venue: 'IEEE Trans. Commun.'
paperurl: ''
citation: 'Ling Cong and Sun Songgeng "<a href=''>Chaotic frequency hopping sequences</a>", IEEE Trans. Commun., vol. 46, pp. 1433-1437, Nov. 1998.'
---
