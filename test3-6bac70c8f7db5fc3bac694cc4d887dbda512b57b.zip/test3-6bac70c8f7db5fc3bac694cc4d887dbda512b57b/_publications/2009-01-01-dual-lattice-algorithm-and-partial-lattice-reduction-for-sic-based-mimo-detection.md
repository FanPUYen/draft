---
title: "Dual-lattice algorithm and partial lattice reduction for SIC-based MIMO detection"
collection: publications
category: manuscripts
permalink: /publication/2009-01-01-dual-lattice-algorithm-and-partial-lattice-reduction-for-sic-based-mimo-detection
date: 2009-01-01
venue: 'IEEE J. Sel. Topics on Signal Processing'
paperurl: ''
citation: 'Cong Ling, Wai Ho Mow, and Lu Gan "<a href=''>Dual-lattice algorithm and partial lattice reduction for SIC-based MIMO detection</a>", IEEE J. Sel. Topics on Signal Processing, vol. 3, pp. 975-985, Dec. 2009.'
---
