---
title: "Coded Caching in a Multi-Server System With Random Topology"
collection: publications
category: manuscripts
permalink: /publication/2020-08-01-mital-coded-caching-random-topology
date: 2020-08-01
venue: 'IEEE Trans. Comm.'
paperurl: ''
citation: 'N. Mital, D. Gunduz, C. Ling. "Coded Caching in a Multi-Server System With Random Topology", <i>IEEE Trans. Comm.</i>, vol. 68, no. 8, pp. 4620-4631, Aug. 2020.'
---
