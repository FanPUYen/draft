---
title: "Hybrid Vector Perturbation Precoding: The Blessing of Approximate Message Passing"
collection: publications
category: manuscripts
permalink: /publication/2019-01-01-lyu-hybrid-vector-perturbation
date: 2019-01-01
venue: 'IEEE Trans. Signal Processing'
paperurl: 'https://arxiv.org/abs/1710.03791'
citation: 'Shanxiang Lyu, Cong Ling. "<a href="https://arxiv.org/abs/1710.03791">Hybrid Vector Perturbation Precoding: The Blessing of Approximate Message Passing</a>", <i>IEEE Trans. Signal Processing</i>, vol. 67, pp. 178-193, Jan. 2019.'
---
