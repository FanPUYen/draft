---
title: "Differential lattice decoding in noncoherent MIMO communication"
collection: publications
category: conferences
permalink: /publication/2005-01-01-differential-lattice-decoding-in-noncoherent-mimo-communication
date: 2005-01-01
venue: 'ICC’05'
paperurl: ''
citation: 'Cong Ling, W. H. Mow, K. H. Li and A. C. Kot "<a href=''>Differential lattice decoding in noncoherent MIMO communication</a>", ICC’05, Seoul, Korea, May 2005.'
---
