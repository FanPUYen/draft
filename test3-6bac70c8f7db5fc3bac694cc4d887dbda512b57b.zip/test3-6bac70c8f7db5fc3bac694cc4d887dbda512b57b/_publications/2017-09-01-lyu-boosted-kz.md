---
title: "Boosted KZ and LLL Algorithms"
collection: publications
category: manuscripts
permalink: /publication/2017-09-01-lyu-boosted-kz
date: 2017-09-01
venue: 'IEEE Trans. Signal Processing'
paperurl: 'https://arxiv.org/abs/1703.03303'
citation: 'Shanxiang Lyu, Cong Ling. "<a href="https://arxiv.org/abs/1703.03303">Boosted KZ and LLL Algorithms</a>", <i>IEEE Trans. Signal Processing</i>, vol. 65, pp. 4784-4796, Sept. 2017.'
---
