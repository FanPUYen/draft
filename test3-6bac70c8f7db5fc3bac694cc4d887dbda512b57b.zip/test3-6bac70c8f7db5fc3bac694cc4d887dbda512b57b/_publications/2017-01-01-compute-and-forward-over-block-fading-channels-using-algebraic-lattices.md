---
title: "Compute-and-Forward over Block-Fading Channels Using Algebraic Lattices"
collection: publications
category: conferences
permalink: /publication/2017-01-01-compute-and-forward-over-block-fading-channels-using-algebraic-lattices
date: 2017-01-01
venue: 'ISIT 2017.'
paperurl: 'https://arxiv.org/abs/1702.01422'
citation: 'Shanxiang Lyu, Antonio Campello, Cong Ling and Jean-Claude Belfiore "<a href="https://arxiv.org/abs/1702.01422">Compute-and-Forward over Block-Fading Channels Using Algebraic Lattices</a>", ISIT 2017.'
---
