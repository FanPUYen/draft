---
title: "Towards characterizing the performance of approximate lattice decoding in MIMO communications"
collection: publications
category: conferences
permalink: /publication/2006-01-01-towards-characterizing-the-performance-of-approximate-lattice-decoding-in-mimo-communications
date: 2006-01-01
venue: 'Int. Symp. Turbo Codes / Int. ITG Conf. Source Channel Coding’06'
paperurl: ''
citation: 'Cong Ling "<a href=''>Towards characterizing the performance of approximate lattice decoding in MIMO communications</a>", Int. Symp. Turbo Codes / Int. ITG Conf. Source Channel Coding’06, Munich, Germany, Apr. 2006.'
---
