---
title: "Approximate lattice decoding: Primal versus dual basis reduction"
collection: publications
category: conferences
permalink: /publication/2006-01-01-approximate-lattice-decoding-primal-versus-dual-basis-reduction
date: 2006-01-01
venue: 'IEEE Int. Symp. Inform. Theory’06'
paperurl: ''
citation: 'Cong Ling "<a href=''>Approximate lattice decoding: Primal versus dual basis reduction</a>", IEEE Int. Symp. Inform. Theory’06, Seattle, July 2006.'
---
