---
title: "Statistical restricted isometry property of orthogonal symmetric Toeplitz matrices"
collection: publications
category: conferences
permalink: /publication/2009-01-01-statistical-restricted-isometry-property-of-orthogonal-symmetric-toeplitz-matrices
date: 2009-01-01
venue: 'IEEE Inform. Theory Workshop 2009'
paperurl: ''
citation: 'Kezhi Li, Cong Ling and Lu Gan "<a href=''>Statistical restricted isometry property of orthogonal symmetric Toeplitz matrices</a>", IEEE Inform. Theory Workshop 2009, Taormina, Italy.'
---
