---
title: "Performance of space-time codes: Gallager bounds and weight enumeration"
collection: publications
category: manuscripts
permalink: /publication/2008-01-01-performance-of-space-time-codes-gallager-bounds-and-weight-enumeration
date: 2008-01-01
venue: 'IEEE Trans. Inform. Theory'
paperurl: ''
citation: 'Cong Ling, K. H. Li and A. C. Kot "<a href=''>Performance of space-time codes: Gallager bounds and weight enumeration</a>", IEEE Trans. Inform. Theory, vol. 54, pp. 3592-3610, Aug. 2008.'
---
