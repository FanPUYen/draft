---
title: "Coprime Sensing via Chinese Remaindering over Quadratic Fields"
collection: publications
category: manuscripts
permalink: /publication/2019-06-01-li-coprime-sensing
date: 2019-06-01
venue: 'IEEE Trans. Signal Processing'
paperurl: 'https://arxiv.org/abs/1808.07505'
citation: 'Conghui Li, Lu Gan, Cong Ling. "Coprime Sensing via Chinese Remaindering over Quadratic Fields," <a href="https://arxiv.org/abs/1808.07505">Part I</a>, <a href="https://arxiv.org/abs/1808.07511">Part II</a>, <i>IEEE Trans. Signal Processing</i>, vol. 67, pp. 2898-2910, 2911-2922, June 2019.'
---
