---
title: "Achievable rates for lattice coding over the Gaussian wiretap channel"
collection: publications
category: conferences
permalink: /publication/2011-01-01-achievable-rates-for-lattice-coding-over-the-gaussian-wiretap-channel
date: 2011-01-01
venue: 'ICC 2011 Physical Layer Security Workshop.'
paperurl: ''
citation: 'Li-Chia Choo, Cong Ling, and Kat-kit Wong "<a href=''>Achievable rates for lattice coding over the Gaussian wiretap channel</a>", ICC 2011 Physical Layer Security Workshop.'
---
