---
title: "Decoding by embedding: Correct decoding radius and DMT optimality"
collection: publications
category: manuscripts
permalink: /publication/2013-01-01-decoding-by-embedding-correct-decoding-radius-and-dmt-optimality
date: 2013-01-01
venue: 'IEEE Trans. Inform. Theory'
paperurl: 'http://arxiv.org/abs/1102.2936'
citation: 'Laura Luzzi, Damien Stehle, and Cong Ling "<a href="http://arxiv.org/abs/1102.2936">Decoding by embedding: Correct decoding radius and DMT optimality</a>", IEEE Trans. Inform. Theory, vol. 59, pp. 1960-2973, May 2013.'
---
