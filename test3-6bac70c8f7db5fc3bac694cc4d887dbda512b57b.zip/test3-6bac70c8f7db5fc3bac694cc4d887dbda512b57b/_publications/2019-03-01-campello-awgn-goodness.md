---
title: "AWGN-Goodness is Enough: Capacity-Achieving Lattice Codes based on Dithered Probabilistic Shaping"
collection: publications
category: manuscripts
permalink: /publication/2019-03-01-campello-awgn-goodness
date: 2019-03-01
venue: 'IEEE Trans. Inform. Theory'
paperurl: 'https://arxiv.org/abs/1707.06688'
citation: 'Antonio Campello, Daniel Dadush, Cong Ling. "<a href="https://arxiv.org/abs/1707.06688">AWGN-Goodness is Enough: Capacity-Achieving Lattice Codes based on Dithered Probabilistic Shaping</a>", <i>IEEE Trans. Inform. Theory</i>, vol. 65, pp. 1961-1971, Mar. 2019.'
---
