---
title: "On complex LLL algorithm for digital communications"
collection: publications
category: manuscripts
permalink: /publication/2007-01-01-on-complex-lll-algorithm-for-digital-communications
date: 2007-01-01
venue: 'LLL+25 Conference'
paperurl: ''
citation: 'Cong Ling and Wai Ho Mow "<a href=''>On complex LLL algorithm for digital communications</a>", LLL+25 Conference, Caen, France, June-July 2007.'
---
