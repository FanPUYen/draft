---
title: "Polar Lattices for Strong Secrecy Over the Mod-Lambda Gaussian Wiretap Channel"
collection: publications
category: conferences
permalink: /publication/2014-01-01-polar-lattices-for-strong-secrecy-over-the-mod-lambda-gaussian-wiretap-channel
date: 2014-01-01
venue: 'ISIT 2014.'
paperurl: ''
citation: 'Yanfei Yan, Ling Liu and Cong Ling "<a href=''>Polar Lattices for Strong Secrecy Over the Mod-Lambda Gaussian Wiretap Channel</a>", ISIT 2014.'
---
