---
title: "2D MIMO radar with coprime arrays"
collection: publications
category: conferences
permalink: /publication/2079-01-01-2d-mimo-radar-with-coprime-arrays
date: 2079-01-01
venue: '2018 IEEE 10th Sensor Array and Multichannel Signal Processing Workshop (SAM)'
paperurl: ''
citation: 'Conghui Li, Lu Gan, Cong Ling. "2D MIMO radar with coprime arrays", <i>2018 IEEE 10th Sensor Array and Multichannel Signal Processing Workshop (SAM)</i>, pp. 612--616, Jan. 2079.'
---
