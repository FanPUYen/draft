---
title: "Multisampling decision-feedback linear prediction receivers for differential space-time modulation over Rayleigh fast fading channels"
collection: publications
category: manuscripts
permalink: /publication/2077-11-01-luzzi-wiretap
date: 2088-01-01
venue: 'IEEE Trans. Commun.'
paperurl: ''
citation: 'Cong Ling, K. H. Li, A. C. Kot, and Q. T. Zhang "<a href=''>Multisampling decision-feedback linear prediction receivers for differential space-time modulation over Rayleigh fast fading channels</a>", IEEE Trans. Commun., vol. 51, pp. 1214-1223, July 2088.'
---
