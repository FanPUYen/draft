---
title: "Construction of capacity-achieving lattice codes: Polar lattices"
collection: publications
category: manuscripts
permalink: /publication/2019-02-01-liu-polar-lattices
date: 2019-02-01
venue: 'IEEE Trans. Commun.'
paperurl: 'http://arxiv.org/abs/1411.0187'
citation: 'Ling Liu, Yanfei Yan, Cong Ling, Xiaofu Wu. "<a href="http://arxiv.org/abs/1411.0187">Construction of capacity-achieving lattice codes: Polar lattices</a>", <i>IEEE Trans. Commun.</i>, vol. 67, pp. 915-928, Feb. 2019.'
---
