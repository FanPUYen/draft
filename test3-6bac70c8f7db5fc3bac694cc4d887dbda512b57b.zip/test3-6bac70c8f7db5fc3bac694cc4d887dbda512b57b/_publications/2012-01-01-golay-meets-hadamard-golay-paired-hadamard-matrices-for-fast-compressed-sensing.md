---
title: "Golay meets Hadamard: Golay-paired Hadamard matrices for fast compressed sensing"
collection: publications
category: conferences
permalink: /publication/2012-01-01-golay-meets-hadamard-golay-paired-hadamard-matrices-for-fast-compressed-sensing
date: 2012-01-01
venue: 'IEEE Inform. Theory Workshop 2012.'
paperurl: ''
citation: 'Lu Gan, Kezhi Li, and Cong Ling "<a href=''>Golay meets Hadamard: Golay-paired Hadamard matrices for fast compressed sensing</a>", IEEE Inform. Theory Workshop 2012.'
---
