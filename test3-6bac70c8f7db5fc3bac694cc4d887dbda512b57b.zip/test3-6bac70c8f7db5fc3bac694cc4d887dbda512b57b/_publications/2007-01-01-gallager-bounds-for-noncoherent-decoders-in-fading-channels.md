---
title: "Gallager bounds for noncoherent decoders in fading channels"
collection: publications
category: manuscripts
permalink: /publication/2007-01-01-gallager-bounds-for-noncoherent-decoders-in-fading-channels
date: 2007-01-01
venue: 'IEEE Trans. Inform. Theory'
paperurl: ''
citation: 'Cong Ling, Xiaofu Wu, K. H. Li, and A. C. Kot "<a href=''>Gallager bounds for noncoherent decoders in fading channels</a>", IEEE Trans. Inform. Theory, vol. 53, pp. 4605-4614, Dec. 2007.'
---
