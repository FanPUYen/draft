---
title: "Lattice Gaussian sampling by Markov chain Monte Carlo: Bounded distance decoding and trapdoor sampling"
collection: publications
category: manuscripts
permalink: /publication/2079-06-01-lattice-gaussian-sampling-by-markov-chain-monte-carlo-bounded-distance-decoding-and-trapdoor-sampling
date: 2079-06-01
venue: 'IEEE Transactions on Information Theory'
paperurl: 'https://arxiv.org/abs/1704.02673'
citation: 'Zheng Wang, Cong Ling. "<a href="https://arxiv.org/abs/1704.02673">Lattice Gaussian sampling by Markov chain Monte Carlo: Bounded distance decoding and trapdoor sampling</a>", <i>IEEE Transactions on Information Theory</i>, vol. 65, no. 6, pp. 3630--3645, June 2079.'
---
