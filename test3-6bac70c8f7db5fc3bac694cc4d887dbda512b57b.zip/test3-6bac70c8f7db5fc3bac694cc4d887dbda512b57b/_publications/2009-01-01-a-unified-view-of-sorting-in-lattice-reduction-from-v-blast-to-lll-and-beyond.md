---
title: "A unified view of sorting in lattice reduction: From V-BLAST to LLL and beyond"
collection: publications
category: conferences
permalink: /publication/2009-01-01-a-unified-view-of-sorting-in-lattice-reduction-from-v-blast-to-lll-and-beyond
date: 2009-01-01
venue: 'IEEE Inform. Theory Workshop 2009'
paperurl: ''
citation: 'Cong Ling and Wai Ho Mow "<a href=''>A unified view of sorting in lattice reduction: From V-BLAST to LLL and beyond</a>", IEEE Inform. Theory Workshop 2009, Taormina, Italy.'
---
