---
title: "A new bound for the orthogonality defect of HKZ reduced lattices"
collection: publications
category: manuscripts
permalink: /publication/2024-03-01-a-new-bound-for-the-orthogonality-defect-of-hkz-reduced-lattices
date: 2024-03-01
venue: 'Research in Number Theory'
paperurl: 'https://link.springer.com/article/10.1007/s40993-024-00554-1'
citation: 'Christian Porter, Edmund Dable-Heath, Cong Ling. "<a href="https://link.springer.com/article/10.1007/s40993-024-00554-1">A new bound for the orthogonality defect of HKZ reduced lattices</a>", <i>Research in Number Theory</i>, vol. 10, no. 3, pp. 65, Mar. 2024.'
---
