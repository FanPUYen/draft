---
title: "On decision-feedback detection of differential space-time modulation in continuous fading"
collection: publications
category: manuscripts
permalink: /publication/2004-01-01-on-decision-feedback-detection-of-differential-space-time-modulation-in-continuous-fading
date: 2004-01-01
venue: 'IEEE Trans. Commun.'
paperurl: ''
citation: 'Cong Ling, K. H. Li and A. C. Kot "<a href=''>On decision-feedback detection of differential space-time modulation in continuous fading</a>", IEEE Trans. Commun., vol. 52, pp. 1613-1617, Oct. 2004.'
---
