---
title: "Performance Limits of Lattice Reduction over Imaginary Quadratic Fields with Applications to Compute-and-Forward"
collection: publications
category: conferences
permalink: /publication/2018-01-01-performance-limits-of-lattice-reduction-over-imaginary-quadratic-fields-with-applications-to-compute-and-forward
date: 2018-01-01
venue: 'ITW 2018.'
paperurl: 'https://arxiv.org/abs/1806.03113'
citation: 'Shanxiang Lyu, Christian Porter, Cong Ling "<a href=''>Performance Limits of Lattice Reduction over Imaginary Quadratic Fields with Applications to Compute-and-Forward</a>", ITW 2018.'
---
