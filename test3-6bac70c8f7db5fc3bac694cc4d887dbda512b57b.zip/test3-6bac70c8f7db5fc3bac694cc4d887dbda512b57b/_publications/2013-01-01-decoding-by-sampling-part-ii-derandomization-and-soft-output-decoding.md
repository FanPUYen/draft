---
title: "Decoding by sampling-Part II: Derandomization and soft-output decoding"
collection: publications
category: manuscripts
permalink: /publication/2013-01-01-decoding-by-sampling-part-ii-derandomization-and-soft-output-decoding
date: 2013-01-01
venue: 'IEEE Trans. Commun.'
paperurl: 'http://arxiv.org/abs/1305.5762'
citation: 'Zheng Wang, Shuiyin Liu and Cong Ling "<a href="http://arxiv.org/abs/1305.5762">Decoding by sampling-Part II: Derandomization and soft-output decoding</a>", IEEE Trans. Commun., vol. 61, no. 11, pp. 4630 – 4639, Nov. 2013.'
---
