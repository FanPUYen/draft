---
title: "Achieving Secrecy Capacity of the Gaussian Wiretap Channel with Polar Lattices"
collection: publications
category: manuscripts
permalink: /publication/2018-03-05-liu-secrecy-capacity
date: 2018-03-05
venue: 'IEEE Trans. Inform. Theory'
paperurl: 'http://arxiv.org/abs/1503.02313'
citation: 'Ling Liu, Yanfei Yan, Cong Ling. "<a href="http://arxiv.org/abs/1503.02313">Achieving Secrecy Capacity of the Gaussian Wiretap Channel with Polar Lattices</a>", <i>IEEE Trans. Inform. Theory</i>, vol. 64, no. 3, pp. 1647-1665, Mar. 2018.'
---
