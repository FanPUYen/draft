---
title: "Decoding by sampling: A randomized lattice algorithm for bounded-distance decoding"
collection: publications
category: manuscripts
permalink: /publication/2011-01-01-decoding-by-sampling-a-randomized-lattice-algorithm-for-bounded-distance-decoding
date: 2011-01-01
venue: 'IEEE Trans. Inform. Theory'
paperurl: 'http://arxiv.org/abs/1003.0064'
citation: 'Shuiyin Liu, Cong Ling, and Damien Stehle "<a href="http://arxiv.org/abs/1003.0064">Decoding by sampling: A randomized lattice algorithm for bounded-distance decoding</a>", IEEE Trans. Inform. Theory, vol. 57, pp. 5933-5945, Sept. 2011.'
---
