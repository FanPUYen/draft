---
title: "Semantically secure lattice codes for the Gaussian wiretap channel"
collection: publications
category: manuscripts
permalink: /publication/2014-01-01-semantically-secure-lattice-codes-for-the-gaussian-wiretap-channel
date: 2014-01-01
venue: 'IEEE Trans. Inform. Theory'
paperurl: 'http://arxiv.org/abs/1210.6673'
citation: 'Cong Ling, Laura Luzzi, Jean-Claude Belfiore, and Damien Stehle "<a href="http://arxiv.org/abs/1210.6673">Semantically secure lattice codes for the Gaussian wiretap channel</a>", IEEE Trans. Inform. Theory, vol. 60, no. 10, pp. 6399–6416, Oct. 2014.'
---
