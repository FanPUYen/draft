---
title: "On the Quantization Goodness of Polar Lattices"
collection: publications
category: conferences
permalink: /publication/2024-01-01-on-the-quantization-goodness-of-polar-lattices
date: 2024-01-01
venue: '2024 IEEE Information Theory Workshop (ITW)'
paperurl: 'https://ieeexplore.ieee.org/abstract/document/10806974'
citation: 'Ling Liu, Shanxiang Lyu, Cong Ling, Baoming Bai. "<a href="https://ieeexplore.ieee.org/abstract/document/10806974">On the Quantization Goodness of Polar Lattices</a>", <i>2024 IEEE Information Theory Workshop (ITW)</i>, pp. 348-353, Jan. 2024.'
---
