---
title: "Derandomized sampling algorithm for lattice decoding"
collection: publications
category: conferences
permalink: /publication/2012-01-01-derandomized-sampling-algorithm-for-lattice-decoding
date: 2012-01-01
venue: 'IEEE Inform. Theory Workshop 2012.'
paperurl: ''
citation: 'Zheng Wang and Cong Ling "<a href=''>Derandomized sampling algorithm for lattice decoding</a>", IEEE Inform. Theory Workshop 2012.'
---
