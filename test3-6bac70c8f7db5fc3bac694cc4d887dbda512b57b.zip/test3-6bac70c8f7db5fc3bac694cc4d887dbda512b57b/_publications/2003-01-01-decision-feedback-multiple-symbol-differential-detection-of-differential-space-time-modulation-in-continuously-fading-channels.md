---
title: "Decision-feedback multiple symbol differential detection of differential space-time modulation in continuously fading channels"
collection: publications
category: manuscripts
permalink: /publication/2003-01-01-decision-feedback-multiple-symbol-differential-detection-of-differential-space-time-modulation-in-continuously-fading-channels
date: 2003-01-01
venue: 'in Proc. ICASSP’03'
paperurl: ''
citation: 'Cong Ling, K. H. Li and A. C. Kot "<a href=''>Decision-feedback multiple symbol differential detection of differential space-time modulation in continuously fading channels</a>", in Proc. ICASSP’03, Hong Kong, China, May 2003, pp. IV_45–IV_48.'
---
