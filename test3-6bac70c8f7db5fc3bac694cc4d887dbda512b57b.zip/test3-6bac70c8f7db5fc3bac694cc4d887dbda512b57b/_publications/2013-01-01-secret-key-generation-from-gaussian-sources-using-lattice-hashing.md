---
title: "Secret key generation from Gaussian sources using lattice hashing"
collection: publications
category: conferences
permalink: /publication/2013-01-01-secret-key-generation-from-gaussian-sources-using-lattice-hashing
date: 2013-01-01
venue: 'ISIT 2013.'
paperurl: ''
citation: 'Cong Ling, Laura Luzzi and Matthieu Bloch "<a href=''>Secret key generation from Gaussian sources using lattice hashing</a>", ISIT 2013.'
---
