---
title: "Artificial-Noise-Aided Physical Layer Phase Challenge-Response Authentication for Practical OFDM Transmission"
collection: publications
category: manuscripts
permalink: /publication/2016-01-01-artificial-noise-aided-physical-layer-phase-challenge-response-authentication-for-practical-ofdm-transmission
date: 2016-01-01
venue: 'IEEE Trans. Wireless Commun.'
paperurl: 'http://arxiv.org/abs/1502.07565'
citation: 'Xiaofu Wu, Zhen Yan, Cong Ling, Xiang-Gen Xia "<a href="http://arxiv.org/abs/1502.07565">Artificial-Noise-Aided Physical Layer Phase Challenge-Response Authentication for Practical OFDM Transmission</a>", IEEE Trans. Wireless Commun., vol. 15, pp. 6611-6625, Oct. 2016.'
---
