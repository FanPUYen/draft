---
title: "Linear prediction receiver for differential space-time modulation over time-correlated Rayleigh fading channels"
collection: publications
category: conferences
permalink: /publication/2002-01-01-linear-prediction-receiver-for-differential-space-time-modulation-over-time-correlated-rayleigh-fading-channels
date: 2002-01-01
venue: 'in Proc. ICC’2002'
paperurl: ''
citation: 'Cong Ling and Xiaofu Wu "<a href=''>Linear prediction receiver for differential space-time modulation over time-correlated Rayleigh fading channels</a>", in Proc. ICC’2002, New York.'
---
