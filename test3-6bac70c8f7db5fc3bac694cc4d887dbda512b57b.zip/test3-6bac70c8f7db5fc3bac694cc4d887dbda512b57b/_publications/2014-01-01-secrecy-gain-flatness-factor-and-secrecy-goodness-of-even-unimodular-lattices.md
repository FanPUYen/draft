---
title: "Secrecy gain, flatness factor, and secrecy-goodness of even unimodular lattices"
collection: publications
category: conferences
permalink: /publication/2014-01-01-secrecy-gain-flatness-factor-and-secrecy-goodness-of-even-unimodular-lattices
date: 2014-01-01
venue: 'ISIT 2014.'
paperurl: ''
citation: 'Fuchun Lin, Cong Ling, and Jean-Claude Belfiore "<a href=''>Secrecy gain, flatness factor, and secrecy-goodness of even unimodular lattices</a>", ISIT 2014.'
---
