---
title: "Reduced and fixed-complexity variants of the LLL algorithm for communications"
collection: publications
category: manuscripts
permalink: /publication/2013-01-01-reduced-and-fixed-complexity-variants-of-the-lll-algorithm-for-communications
date: 2013-01-01
venue: 'IEEE Trans. Commun.'
paperurl: 'http://arxiv.org/abs/1006.1661'
citation: 'Cong Ling, Wai Ho Mow, and Nick Howgrave-Graham "<a href="http://arxiv.org/abs/1006.1661">Reduced and fixed-complexity variants of the LLL algorithm for communications</a>", IEEE Trans. Commun., vol. 61, pp. 1040-1050, Mar. 2013.'
---
