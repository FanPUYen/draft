---
title: "On the Geometric Ergodicity of Metropolis-Hastings Algorithms for Lattice Gaussian Sampling"
collection: publications
category: manuscripts
permalink: /publication/2018-02-02-wang-ergodicity
date: 2018-02-02
venue: 'IEEE Trans. Inform. Theory'
paperurl: 'http://arxiv.org/abs/1501.05757'
citation: 'Zheng Wang, Cong Ling. "<a href="http://arxiv.org/abs/1501.05757">On the Geometric Ergodicity of Metropolis-Hastings Algorithms for Lattice Gaussian Sampling</a>", <i>IEEE Trans. Inform. Theory</i>, vol. 64, no. 2, pp. 738-751, Feb. 2018.'
---
