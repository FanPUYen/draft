---
title: "Towards understanding weighted bit-flipping decoding"
collection: publications
category: conferences
permalink: /publication/2007-01-01-towards-understanding-weighted-bit-flipping-decoding
date: 2007-01-01
venue: 'IEEE Int. Symp. Inform. Theory’07'
paperurl: ''
citation: 'Xiaofu Wu, Cong Ling et al. "<a href=''>Towards understanding weighted bit-flipping decoding</a>", IEEE Int. Symp. Inform. Theory’07, Nice, France, June 2007.'
---
