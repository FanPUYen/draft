---
title: "Algebraic Lattice Codes Achieve the Capacity of the Compound Block-Fading Channel"
collection: publications
category: conferences
permalink: /publication/2016-01-01-algebraic-lattice-codes-achieve-the-capacity-of-the-compound-block-fading-channel
date: 2016-01-01
venue: 'ISIT 2016.'
paperurl: 'http://arxiv.org/abs/1603.09263'
citation: 'Antonio Campello, Cong Ling and Jean-Claude Belfiore "<a href="http://arxiv.org/abs/1603.09263">Algebraic Lattice Codes Achieve the Capacity of the Compound Block-Fading Channel</a>", ISIT 2016.'
---
