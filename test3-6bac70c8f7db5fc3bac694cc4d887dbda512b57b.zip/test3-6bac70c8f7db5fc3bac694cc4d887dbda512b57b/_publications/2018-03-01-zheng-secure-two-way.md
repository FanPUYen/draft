---
title: "Secure Polar Coding for the Two-Way Wiretap Channel"
collection: publications
category: manuscripts
permalink: /publication/2018-03-01-zheng-secure-two-way
date: 2018-03-01
venue: 'IEEE Access'
paperurl: 'https://arxiv.org/abs/1612.00130'
citation: 'Mengfan Zheng, Meixia Tao, Wen Chen, Cong Ling. "<a href="https://arxiv.org/abs/1612.00130">Secure Polar Coding for the Two-Way Wiretap Channel</a>", <i>IEEE Access</i>, vol. 6, pp. 21731-21744, Mar. 2018.'
---
