---
title: "A construction of lattices from polar codes"
collection: publications
category: conferences
permalink: /publication/2012-01-01-a-construction-of-lattices-from-polar-codes
date: 2012-01-01
venue: 'IEEE Inform. Theory Workshop 2012.'
paperurl: ''
citation: 'Yanfei Yan and Cong Ling "<a href=''>A construction of lattices from polar codes</a>", IEEE Inform. Theory Workshop 2012.'
---
