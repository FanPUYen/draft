---
title: "Computation of the Para-Pseudo Inverse for Oversampled Filter Banks: Forward and Backward Greville Formulas"
collection: publications
category: manuscripts
permalink: /publication/2008-01-01-computation-of-the-para-pseudo-inverse-for-oversampled-filter-banks-forward-and-backward-greville-formulas
date: 2008-01-01
venue: 'IEEE Trans. Signal Processing'
paperurl: ''
citation: 'Lu Gan and Cong Ling "<a href=''>Computation of the Para-Pseudo Inverse for Oversampled Filter Banks: Forward and Backward Greville Formulas</a>", IEEE Trans. Signal Processing, vol. 56, pp. 5851 – 5860, Dec. 2008.'
---
