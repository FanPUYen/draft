---
title: "Convolutional compressed sensing using deterministic sequences"
collection: publications
category: manuscripts
permalink: /publication/2013-01-01-convolutional-compressed-sensing-using-deterministic-sequences
date: 2013-01-01
venue: 'IEEE Trans. Signal Processing'
paperurl: 'http://arxiv.org/abs/1210.7506'
citation: 'Kezhi Li, Lu Gan, and Cong Ling "<a href="http://arxiv.org/abs/1210.7506">Convolutional compressed sensing using deterministic sequences</a>", IEEE Trans. Signal Processing, vol. 61, pp. 740-752, Feb. 2013.'
---
