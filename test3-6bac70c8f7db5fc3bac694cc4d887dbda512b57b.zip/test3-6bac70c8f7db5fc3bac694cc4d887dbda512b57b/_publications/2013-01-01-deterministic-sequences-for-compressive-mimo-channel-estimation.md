---
title: "Deterministic sequences for compressive MIMO channel estimation"
collection: publications
category: manuscripts
permalink: /publication/2013-01-01-deterministic-sequences-for-compressive-mimo-channel-estimation
date: 2013-01-01
venue: 'EUSIPCO 2013.'
paperurl: ''
citation: 'Peng Zhang, Lu Gan, Sumei Sun and Cong Ling "<a href=''>Deterministic sequences for compressive MIMO channel estimation</a>", EUSIPCO 2013.'
---
