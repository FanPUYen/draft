---
title: "Randomized lattice decoding: Bridging the gap between lattice reduction and sphere decoding"
collection: publications
category: conferences
permalink: /publication/2010-01-01-randomized-lattice-decoding-bridging-the-gap-between-lattice-reduction-and-sphere-decoding
date: 2010-01-01
venue: 'IEEE Int. Symp. Inform. Theory’10'
paperurl: ''
citation: 'Shuiyin Liu, Cong Ling, and Damien Stehle "<a href=''>Randomized lattice decoding: Bridging the gap between lattice reduction and sphere decoding</a>", IEEE Int. Symp. Inform. Theory’10, Austin, US, June 2010.'
---
