---
title: "Multiple-Antenna differential lattice decoding"
collection: publications
category: manuscripts
permalink: /publication/2005-01-01-multiple-antenna-differential-lattice-decoding
date: 2005-01-01
venue: 'IEEE J-SAC'
paperurl: ''
citation: 'Cong Ling, W. H. Mow, K. H. Li and A. C. Kot "<a href=''>Multiple-Antenna differential lattice decoding</a>", IEEE J-SAC, vol. 23, pp.1821-1829, Sept. 2005.'
---
