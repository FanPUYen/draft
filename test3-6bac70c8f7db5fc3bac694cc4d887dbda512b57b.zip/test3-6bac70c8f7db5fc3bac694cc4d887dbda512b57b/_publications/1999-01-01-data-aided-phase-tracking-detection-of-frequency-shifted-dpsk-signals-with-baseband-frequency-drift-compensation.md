---
title: "Data-aided phase tracking detection of frequency-shifted DPSK signals with baseband frequency-drift compensation"
collection: publications
category: manuscripts
permalink: /publication/1999-01-01-data-aided-phase-tracking-detection-of-frequency-shifted-dpsk-signals-with-baseband-frequency-drift-compensation
date: 1999-01-01
venue: 'Electron. Lett.'
paperurl: ''
citation: 'Xiaofu Wu, Cong Ling and Songgeng Sun "<a href=''>Data-aided phase tracking detection of frequency-shifted DPSK signals with baseband frequency-drift compensation</a>", Electron. Lett., vol.35, no.15, pp. 1222-1223, July 1999.'
---
