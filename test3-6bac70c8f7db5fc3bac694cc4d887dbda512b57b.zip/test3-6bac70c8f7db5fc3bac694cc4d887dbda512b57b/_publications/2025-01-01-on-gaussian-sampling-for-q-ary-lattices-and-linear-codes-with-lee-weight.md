---
title: "On Gaussian Sampling for $q$-ary Lattices and Linear Codes with Lee Weight"
collection: publications
category: conferences
permalink: /publication/2025-01-01-on-gaussian-sampling-for-q-ary-lattices-and-linear-codes-with-lee-weight
date: 2025-01-01
venue: 'Cryptology ePrint Archive, Paper 2025/087'
paperurl: 'https://eprint.iacr.org/2025/087'
citation: 'Maiara F. Bollauf, Maja Lie, Cong Ling. "<a href="https://eprint.iacr.org/2025/087">On Gaussian Sampling for $q$-ary Lattices and Linear Codes with Lee Weight</a>", <i>Cryptology ePrint Archive, Paper 2025/087</i>, Jan. 2025.'
---
