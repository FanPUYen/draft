---
title: "Proximity factors of lattice reduction-aided precoding for multiantenna broadcast"
collection: publications
category: conferences
permalink: /publication/2012-01-01-proximity-factors-of-lattice-reduction-aided-precoding-for-multiantenna-broadcast
date: 2012-01-01
venue: 'ISIT 2012.'
paperurl: ''
citation: 'Suiyin Liu, Cong Ling and Xiaofu Wu "<a href=''>Proximity factors of lattice reduction-aided precoding for multiantenna broadcast</a>", ISIT 2012.'
---
