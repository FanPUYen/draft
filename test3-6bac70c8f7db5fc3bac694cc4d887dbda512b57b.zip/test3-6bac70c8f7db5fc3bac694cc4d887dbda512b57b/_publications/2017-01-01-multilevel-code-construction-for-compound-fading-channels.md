---
title: "Multilevel Code Construction for Compound Fading Channels"
collection: publications
category: conferences
permalink: /publication/2017-01-01-multilevel-code-construction-for-compound-fading-channels
date: 2017-01-01
venue: 'ISIT 2017.'
paperurl: 'https://arxiv.org/abs/1701.08314'
citation: 'Antonio Campello, Ling Liu and Cong Ling "<a href="https://arxiv.org/abs/1701.08314">Multilevel Code Construction for Compound Fading Channels</a>", ISIT 2017.'
---
