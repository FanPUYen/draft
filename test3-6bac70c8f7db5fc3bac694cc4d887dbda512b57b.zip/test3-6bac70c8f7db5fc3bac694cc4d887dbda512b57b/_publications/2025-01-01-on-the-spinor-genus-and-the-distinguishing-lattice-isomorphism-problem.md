---
title: "On the Spinor Genus and the Distinguishing Lattice Isomorphism Problem"
collection: publications
category: conferences
permalink: /publication/2025-01-01-on-the-spinor-genus-and-the-distinguishing-lattice-isomorphism-problem
date: 2025-01-01
venue: 'Advances in Cryptology -- ASIACRYPT 2024'
paperurl: 'https://link.springer.com/chapter/10.1007/978-981-96-0894-2_11'
citation: 'Cong
and Liu, Jingbo
and Mendelsohn, Andrew Ling. "<a href="https://link.springer.com/chapter/10.1007/978-981-96-0894-2_11">On the Spinor Genus and the Distinguishing Lattice Isomorphism Problem</a>", <i>Advances in Cryptology -- ASIACRYPT 2024</i>, pp. 329--358, Jan. 2025.'
---
