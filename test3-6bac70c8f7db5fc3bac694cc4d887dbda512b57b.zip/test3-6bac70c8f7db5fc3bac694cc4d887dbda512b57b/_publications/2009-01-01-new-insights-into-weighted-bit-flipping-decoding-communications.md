---
title: "New insights into weighted bit-flipping decoding Communications"
collection: publications
category: manuscripts
permalink: /publication/2009-01-01-new-insights-into-weighted-bit-flipping-decoding-communications
date: 2009-01-01
venue: 'IEEE Trans. Commun.'
paperurl: ''
citation: 'Xiaofu Wu, Cong Ling, Ming Jiang, Enyang Xu, Chunming Zhao, and Xiaohu You "<a href=''>New insights into weighted bit-flipping decoding Communications</a>", IEEE Trans. Commun., vol. 57, pp. 2177 – 2180, Aug. 2009.'
---
