---
title: "New Gallager bounds in block fading channels"
collection: publications
category: manuscripts
permalink: /publication/2007-01-01-new-gallager-bounds-in-block-fading-channels
date: 2007-01-01
venue: 'IEEE Trans. Inform. Theory'
paperurl: ''
citation: 'Xiaofu Wu, Haige Xiang and Cong Ling "<a href=''>New Gallager bounds in block fading channels</a>", IEEE Trans. Inform. Theory, vol. 53, pp. 684-694, Feb. 2007.'
---
