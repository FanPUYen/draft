---
title: "On the Diversity of Linear Transceivers in MIMO AF Relaying Systems"
collection: publications
category: manuscripts
permalink: /publication/2016-01-01-on-the-diversity-of-linear-transceivers-in-mimo-af-relaying-systems
date: 2016-01-01
venue: 'IEEE Trans. Inform. Theory'
paperurl: 'http://arxiv.org/abs/1403.2081'
citation: 'Changick Song and Cong Ling "<a href="http://arxiv.org/abs/1403.2081">On the Diversity of Linear Transceivers in MIMO AF Relaying Systems</a>",  IEEE Trans. Inform. Theory, vol. 62, no. 1, pp. 272–289, Jan. 2016.'
---
