---
title: "Effective LLL reduction for lattice decoding"
collection: publications
category: conferences
permalink: /publication/2007-01-01-effective-lll-reduction-for-lattice-decoding
date: 2007-01-01
venue: 'IEEE Int. Symp. Inform. Theory’07'
paperurl: ''
citation: 'Cong Ling and Nick Howgrave-Graham "<a href=''>Effective LLL reduction for lattice decoding</a>", IEEE Int. Symp. Inform. Theory’07, Nice, France, June 2007.'
---
